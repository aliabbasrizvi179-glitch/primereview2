import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User role enum
export const userRoleEnum = pgEnum('user_role', ['user', 'brand', 'admin']);

// User status enum
export const userStatusEnum = pgEnum('user_status', ['active', 'blocked', 'pending']);

// Campaign status enum
export const campaignStatusEnum = pgEnum('campaign_status', ['active', 'paused', 'completed', 'cancelled']);

// Review status enum
export const reviewStatusEnum = pgEnum('review_status', ['pending', 'approved', 'declined']);

// Payment status enum
export const paymentStatusEnum = pgEnum('payment_status', ['pending', 'completed', 'failed', 'cancelled']);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  phone: varchar("phone"),
  role: userRoleEnum("role").notNull().default('user'),
  status: userStatusEnum("status").notNull().default('active'),
  walletBalance: decimal("wallet_balance", { precision: 10, scale: 2 }).default('0'),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).default('0'),
  referralCode: varchar("referral_code").unique(),
  referredBy: varchar("referred_by"),
  // Verification fields
  isEmailVerified: boolean("is_email_verified").default(false),
  isPhoneVerified: boolean("is_phone_verified").default(false),
  googleEmail: varchar("google_email"), // Verified Google email
  emailVerificationCode: varchar("email_verification_code"),
  phoneVerificationCode: varchar("phone_verification_code"),
  verificationCodeExpiry: timestamp("verification_code_expiry"),
  isAccountVerified: boolean("is_account_verified").default(false), // Overall verification status
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Categories table
export const categories = pgTable("categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  minPrice: decimal("min_price", { precision: 8, scale: 2 }).notNull(),
  maxPrice: decimal("max_price", { precision: 8, scale: 2 }).notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Campaigns table
export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  brandId: varchar("brand_id").notNull(),
  categoryId: varchar("category_id").notNull(),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  rewardAmount: decimal("reward_amount", { precision: 8, scale: 2 }).notNull(),
  totalReviewsNeeded: integer("total_reviews_needed").notNull(),
  completedReviews: integer("completed_reviews").default(0),
  status: campaignStatusEnum("status").default('active'),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  requirements: text("requirements"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Reviews table
export const reviews = pgTable("reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  campaignId: varchar("campaign_id").notNull(),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(),
  proofImages: text("proof_images").array(),
  status: reviewStatusEnum("status").default('pending'),
  adminNotes: text("admin_notes"),
  rewardAmount: decimal("reward_amount", { precision: 8, scale: 2 }).notNull(),
  submittedAt: timestamp("submitted_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
  // Anti-fraud fields
  imageHash: varchar("image_hash"), // Hash of uploaded images for duplicate detection
  ipAddress: varchar("ip_address"), // IP address for rate limiting
  deviceFingerprint: varchar("device_fingerprint"), // Device identification
  submissionCount: integer("submission_count").default(1), // Daily submission count
});

// Payments table
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: varchar("type").notNull(), // 'deposit', 'withdrawal', 'review_payment'
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: paymentStatusEnum("status").default('pending'),
  paymentMethod: varchar("payment_method"), // 'upi', 'razorpay'
  paymentDetails: jsonb("payment_details"),
  transactionId: varchar("transaction_id"),
  razorpayOrderId: varchar("razorpay_order_id"), // Razorpay order ID
  razorpayPaymentId: varchar("razorpay_payment_id"), // Razorpay payment ID
  upiTransactionId: varchar("upi_transaction_id"), // UPI transaction reference
  webhookVerified: boolean("webhook_verified").default(false), // Webhook verification status
  createdAt: timestamp("created_at").defaultNow(),
  processedAt: timestamp("processed_at"),
});

// Homepage sliders table
export const sliders = pgTable("sliders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  position: integer("position").notNull(), // 1, 2, 3
  title: varchar("title").notNull(),
  description: text("description"),
  backgroundImage: varchar("background_image"),
  buttonText: varchar("button_text"),
  buttonLink: varchar("button_link"),
  isActive: boolean("is_active").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  type: varchar("type").notNull(), // 'campaign', 'review', 'payment', 'system'
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Referrals table
export const referrals = pgTable("referrals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  referrerId: varchar("referrer_id").notNull(), // User who made the referral
  referredId: varchar("referred_id").notNull(), // User who was referred
  referralCode: varchar("referral_code").notNull(), // Code that was used
  rewardAmount: decimal("reward_amount", { precision: 8, scale: 2 }).notNull(),
  isPaid: boolean("is_paid").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  paidAt: timestamp("paid_at"),
});

// Fraud detection table
export const fraudDetection = pgTable("fraud_detection", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: varchar("type").notNull(), // 'duplicate_image', 'rate_limit', 'suspicious_activity'
  description: text("description").notNull(),
  metadata: jsonb("metadata"), // Additional fraud data
  severity: varchar("severity").notNull(), // 'low', 'medium', 'high'
  status: varchar("status").notNull().default('pending'), // 'pending', 'reviewed', 'resolved'
  createdAt: timestamp("created_at").defaultNow(),
});

// Rate limiting table
export const rateLimits = pgTable("rate_limits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  identifier: varchar("identifier").notNull(), // IP address or user ID
  action: varchar("action").notNull(), // 'review_submission', 'payment_request'
  count: integer("count").notNull().default(1),
  windowStart: timestamp("window_start").defaultNow(),
  lastActivity: timestamp("last_activity").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  campaigns: many(campaigns),
  reviews: many(reviews),
  payments: many(payments),
  notifications: many(notifications),
  referralsMade: many(referrals, { relationName: "referrer" }),
  referralsReceived: many(referrals, { relationName: "referred" }),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  brand: one(users, { fields: [campaigns.brandId], references: [users.id] }),
  category: one(categories, { fields: [campaigns.categoryId], references: [categories.id] }),
  reviews: many(reviews),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  user: one(users, { fields: [reviews.userId], references: [users.id] }),
  campaign: one(campaigns, { fields: [reviews.campaignId], references: [campaigns.id] }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, { fields: [payments.userId], references: [users.id] }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
}));

export const referralsRelations = relations(referrals, ({ one }) => ({
  referrer: one(users, { fields: [referrals.referrerId], references: [users.id], relationName: "referrer" }),
  referred: one(users, { fields: [referrals.referredId], references: [users.id], relationName: "referred" }),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  campaigns: many(campaigns),
}));

export const fraudDetectionRelations = relations(fraudDetection, ({ one }) => ({
  user: one(users, { fields: [fraudDetection.userId], references: [users.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const upsertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
  role: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  completedReviews: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  submittedAt: true,
  reviewedAt: true,
  status: true,
  adminNotes: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  processedAt: true,
});

export const insertSliderSchema = createInsertSchema(sliders).omit({
  id: true,
  updatedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  createdAt: true,
  paidAt: true,
});

export const insertFraudDetectionSchema = createInsertSchema(fraudDetection).omit({
  id: true,
  createdAt: true,
});

export const insertRateLimitSchema = createInsertSchema(rateLimits).omit({
  id: true,
  windowStart: true,
  lastActivity: true,
});

// Types
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type Category = typeof categories.$inferSelect;

export type Slider = typeof sliders.$inferSelect;
export type InsertSlider = z.infer<typeof insertSliderSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;

export type FraudDetection = typeof fraudDetection.$inferSelect;
export type InsertFraudDetection = z.infer<typeof insertFraudDetectionSchema>;

export type RateLimit = typeof rateLimits.$inferSelect;
export type InsertRateLimit = z.infer<typeof insertRateLimitSchema>;
