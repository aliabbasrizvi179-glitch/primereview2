# PrimeReview Admin Panel - Standalone Deployment Guide

## 📦 Package Contents

The `primereview-admin-panel-standalone.tar.gz` file contains a complete standalone admin panel that can be deployed independently from the main PrimeReview platform.

### What's Included:
- ✅ **Complete React Admin Dashboard** - Fully functional admin interface
- ✅ **Database Control Panel** - Direct CRUD operations on all tables
- ✅ **User Management Interface** - Create, view, edit users
- ✅ **Campaign Management** - Full campaign oversight capabilities
- ✅ **Brand Management** - Handle brand accounts and approvals
- ✅ **Review Management** - Approve/reject review submissions
- ✅ **Payment Management** - Handle payments and withdrawals
- ✅ **Analytics Dashboard** - Platform performance metrics
- ✅ **System Settings** - Platform configuration tools

## 🚀 Quick Deployment

### Step 1: Extract the Package
```bash
tar -xzf primereview-admin-panel-standalone.tar.gz
cd admin-panel-standalone
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Configure Environment
```bash
cp .env.example .env
# Edit .env and set your API URL
VITE_API_URL=https://your-main-platform-api.com
```

### Step 4: Start the Admin Panel
```bash
# Development
npm run dev

# Production Build
npm run build
npm run preview
```

## 🔧 Configuration

### API Connection
The admin panel connects to your main PrimeReview API server. Set the `VITE_API_URL` in your `.env` file:

- **Development**: `http://localhost:5000`
- **Production**: `https://your-api-domain.com`

### Port Settings
- **Default Port**: 3001
- **Change Port**: Edit `vite.config.ts` → server → port

## 🛡️ Security Requirements

### Authentication
The admin panel requires:
1. Valid admin user authentication
2. Proper session management
3. HTTPS in production

### Access Control
- Restrict to authorized admin IPs only
- Use firewall rules for additional security
- Regular security audits recommended

## 📊 Database Control Features

### Direct Database Management
- **Users Table**: Create, view, edit, bulk operations
- **Campaigns Table**: Full CRUD operations
- **Reviews Table**: Approval workflow management
- **Categories Table**: Pricing tier management
- **Payments Table**: Transaction oversight
- **Notifications Table**: System messaging

### Advanced Operations
- **Database Backup**: Export complete database
- **Database Restore**: Import from backup
- **SQL Query Execution**: Direct database queries
- **Bulk Data Export**: CSV/JSON exports

## 🌐 Production Deployment

### Option 1: Separate Server
Deploy on a dedicated admin server:
```bash
# Build for production
npm run build

# Serve with nginx or apache
# Point domain: admin.yourdomain.com
```

### Option 2: Same Server, Different Port
Run alongside main app:
```bash
# Main app on port 5000
# Admin panel on port 3001
# Use reverse proxy for routing
```

### Option 3: Subdomain Deployment
```nginx
# nginx configuration
server {
    server_name admin.yourdomain.com;
    location / {
        proxy_pass http://localhost:3001;
    }
}
```

## 🔧 Troubleshooting

### Common Issues

**1. API Connection Failed**
- Check VITE_API_URL in .env
- Verify main platform is running
- Check CORS settings

**2. Authentication Errors**
- Ensure admin user exists in main platform
- Check session configuration
- Verify auth endpoints

**3. Build Errors**
- Run `npm install` to ensure dependencies
- Check Node.js version (16+ recommended)
- Clear npm cache if needed

## 📞 Support

For technical support:
1. Check the README.md in the package
2. Verify environment configuration
3. Test API connectivity
4. Contact development team

## 🔄 Updates

To update the admin panel:
1. Download new package version
2. Backup current configuration
3. Extract new version
4. Restore configuration
5. Run `npm install` for new dependencies

---

**Note**: This admin panel provides complete control over your PrimeReview platform. Use with appropriate security measures and restrict access to authorized personnel only.