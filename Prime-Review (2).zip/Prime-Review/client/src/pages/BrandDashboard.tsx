import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import CampaignModal from "@/components/CampaignModal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function BrandDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [showCampaignModal, setShowCampaignModal] = useState(false);

  // Redirect if not authenticated or not a brand
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || (user as any)?.role !== 'brand')) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery({
    queryKey: ["/api/campaigns/brand", (user as any)?.id],
    enabled: !!(user as any)?.id,
  });

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  const handleBackToHome = () => {
    window.location.href = '/';
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.charAt(0) || ""}${lastName?.charAt(0) || ""}`.toUpperCase();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const activeCampaigns = (campaigns as any[]).filter((c: any) => c.status === 'active');
  const totalReviews = (campaigns as any[]).reduce((acc: number, c: any) => acc + c.completedReviews, 0);
  const pendingReviews = (campaigns as any[]).reduce((acc: number, c: any) => acc + (c.totalReviewsNeeded - c.completedReviews), 0);
  const monthlySpend = (campaigns as any[]).reduce((acc: number, c: any) => acc + (parseFloat(c.rewardAmount) * c.completedReviews), 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Dashboard Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-primary" data-testid="logo">primereview</h1>
              <span className="text-sm bg-primary/10 text-primary px-3 py-1 rounded-full font-medium">Brand Dashboard</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-muted px-4 py-2 rounded-lg">
                <i className="fas fa-credit-card text-primary"></i>
                <span className="font-semibold text-foreground" data-testid="brand-balance">₹{(user as any)?.walletBalance || '0'}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleBackToHome}
                data-testid="button-home"
              >
                <i className="fas fa-home mr-2"></i>
                Home
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="profile-menu-trigger">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={(user as any)?.profileImageUrl} alt={`${(user as any)?.firstName} ${(user as any)?.lastName}`} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials((user as any)?.firstName, (user as any)?.lastName)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none" data-testid="profile-name">
                        {(user as any)?.firstName} {(user as any)?.lastName}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground" data-testid="profile-email">
                        {(user as any)?.email}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground capitalize" data-testid="profile-role">
                        Role: {(user as any)?.role}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <a href="/profile" className="cursor-pointer" data-testid="profile-menu-profile">
                      <i className="fas fa-user mr-2 h-4 w-4"></i>
                      <span>Profile Settings</span>
                    </a>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <div className="cursor-default" data-testid="profile-menu-wallet">
                      <i className="fas fa-wallet mr-2 h-4 w-4"></i>
                      <span>Wallet: ₹{(user as any)?.walletBalance || '0'}</span>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600" data-testid="profile-menu-logout">
                    <i className="fas fa-sign-out-alt mr-2 h-4 w-4"></i>
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>
      
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-card border-r border-border min-h-screen">
          <nav className="p-6">
            <ul className="space-y-2">
              <li><a href="#" className="flex items-center space-x-3 text-primary bg-primary/10 px-4 py-3 rounded-lg font-medium" data-testid="nav-dashboard">
                <i className="fas fa-home"></i><span>Dashboard</span>
              </a></li>
              <li><a href="#" className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-campaigns">
                <i className="fas fa-bullhorn"></i><span>Campaigns</span>
              </a></li>
              <li><a href="#" className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-reviews">
                <i className="fas fa-star"></i><span>Reviews</span>
              </a></li>
              <li><a href="#" className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-analytics">
                <i className="fas fa-chart-bar"></i><span>Analytics</span>
              </a></li>
              <li><a href="#" className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-payments">
                <i className="fas fa-credit-card"></i><span>Payments</span>
              </a></li>
            </ul>
          </nav>
        </aside>
        
        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-foreground">Brand Dashboard</h2>
            <div className="flex space-x-3">
              <Button variant="secondary" data-testid="button-single-review">
                <i className="fas fa-plus mr-2"></i>Single Review
              </Button>
              <Button onClick={() => setShowCampaignModal(true)} data-testid="button-new-campaign">
                <i className="fas fa-plus mr-2"></i>New Campaign
              </Button>
            </div>
          </div>
          
          {/* Campaign Performance Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Active Campaigns</p>
                    <p className="text-2xl font-bold text-foreground" data-testid="stat-active-campaigns">{activeCampaigns.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <i className="fas fa-bullhorn text-primary text-lg"></i>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Reviews</p>
                    <p className="text-2xl font-bold text-foreground" data-testid="stat-total-reviews">{totalReviews}</p>
                  </div>
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <i className="fas fa-star text-accent text-lg"></i>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Pending Reviews</p>
                    <p className="text-2xl font-bold text-foreground" data-testid="stat-pending-reviews">{pendingReviews}</p>
                  </div>
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <i className="fas fa-clock text-yellow-600 text-lg"></i>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Spend</p>
                    <p className="text-2xl font-bold text-foreground" data-testid="stat-monthly-spend">₹{monthlySpend.toFixed(0)}</p>
                  </div>
                  <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                    <i className="fas fa-rupee-sign text-primary text-lg"></i>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Recent Campaigns */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-foreground">Recent Campaigns</h3>
              </div>
              
              {campaignsLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse h-16 bg-muted rounded-lg"></div>
                  ))}
                </div>
              ) : (campaigns as any[]).length === 0 ? (
                <div className="text-center py-8">
                  <i className="fas fa-bullhorn text-muted-foreground text-4xl mb-4"></i>
                  <p className="text-muted-foreground">No campaigns created yet. Create your first campaign!</p>
                  <Button onClick={() => setShowCampaignModal(true)} className="mt-4" data-testid="button-create-first-campaign">
                    Create Campaign
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 text-muted-foreground font-medium">Campaign</th>
                        <th className="text-left py-3 px-4 text-muted-foreground font-medium">Status</th>
                        <th className="text-left py-3 px-4 text-muted-foreground font-medium">Reviews</th>
                        <th className="text-left py-3 px-4 text-muted-foreground font-medium">Spent</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(campaigns as any[]).map((campaign: any) => (
                        <tr key={campaign.id} className="border-b border-border hover:bg-muted/50 transition-colors" data-testid={`campaign-row-${campaign.id}`}>
                          <td className="py-4 px-4">
                            <div>
                              <p className="font-medium text-foreground" data-testid={`campaign-name-${campaign.id}`}>{campaign.title}</p>
                              <p className="text-sm text-muted-foreground" data-testid={`campaign-end-date-${campaign.id}`}>
                                Ends {new Date(campaign.endDate).toLocaleDateString()}
                              </p>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              campaign.status === 'active' 
                                ? 'bg-accent/10 text-accent'
                                : 'bg-muted text-muted-foreground'
                            }`} data-testid={`campaign-status-${campaign.id}`}>
                              {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                            </span>
                          </td>
                          <td className="py-4 px-4">
                            <div className="text-sm">
                              <span className="font-medium text-foreground" data-testid={`campaign-completed-${campaign.id}`}>{campaign.completedReviews}</span>
                              <span className="text-muted-foreground">/ {campaign.totalReviewsNeeded}</span>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <span className="font-medium text-foreground" data-testid={`campaign-spent-${campaign.id}`}>
                              ₹{(parseFloat(campaign.rewardAmount) * campaign.completedReviews).toFixed(0)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      <CampaignModal
        isOpen={showCampaignModal}
        onClose={() => setShowCampaignModal(false)}
      />
    </div>
  );
}
