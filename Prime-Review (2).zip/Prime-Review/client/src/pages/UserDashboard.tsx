import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import ReviewModal from "@/components/ReviewModal";
import WalletModal from "@/components/WalletModal";
import ReferralModal from "@/components/ReferralModal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function UserDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Verification is now optional

  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery({
    queryKey: ["/api/campaigns"],
    enabled: isAuthenticated,
  });

  const { data: userReviews = [] } = useQuery({
    queryKey: ["/api/reviews/user", (user as any)?.id],
    enabled: !!(user as any)?.id,
  });

  const handleAcceptCampaign = (campaign: any) => {
    setSelectedCampaign(campaign);
    setShowReviewModal(true);
  };

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  const handleBackToHome = () => {
    window.location.href = '/';
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.charAt(0) || ""}${lastName?.charAt(0) || ""}`.toUpperCase();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Dashboard Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-primary" data-testid="logo">primereview</h1>
              <span className="text-sm bg-accent/10 text-accent px-3 py-1 rounded-full font-medium">Reviewer Dashboard</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-accent/10 px-4 py-2 rounded-lg">
                <i className="fas fa-coins text-accent"></i>
                <span className="font-semibold text-foreground" data-testid="wallet-balance">₹{(user as any)?.walletBalance || '0'}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleBackToHome}
                data-testid="button-home"
              >
                <i className="fas fa-home mr-2"></i>
                Home
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowWalletModal(true)}
                data-testid="button-wallet"
              >
                <i className="fas fa-wallet"></i>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="profile-menu-trigger">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={(user as any)?.profileImageUrl} alt={`${(user as any)?.firstName} ${(user as any)?.lastName}`} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials((user as any)?.firstName, (user as any)?.lastName)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none" data-testid="profile-name">
                        {(user as any)?.firstName} {(user as any)?.lastName}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground" data-testid="profile-email">
                        {(user as any)?.email}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground capitalize" data-testid="profile-role">
                        Role: {(user as any)?.role}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <a href="/profile" className="cursor-pointer" data-testid="profile-menu-profile">
                      <i className="fas fa-user mr-2 h-4 w-4"></i>
                      <span>Profile Settings</span>
                    </a>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <div className="cursor-default" data-testid="profile-menu-wallet">
                      <i className="fas fa-wallet mr-2 h-4 w-4"></i>
                      <span>Wallet: ₹{(user as any)?.walletBalance || '0'}</span>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600" data-testid="profile-menu-logout">
                    <i className="fas fa-sign-out-alt mr-2 h-4 w-4"></i>
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>
      
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-card border-r border-border min-h-screen">
          <nav className="p-6">
            <ul className="space-y-2">
              <li><a href="#" className="flex items-center space-x-3 text-primary bg-primary/10 px-4 py-3 rounded-lg font-medium" data-testid="nav-dashboard">
                <i className="fas fa-home"></i><span>Dashboard</span>
              </a></li>
              <li><a href="#" className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-campaigns">
                <i className="fas fa-list-alt"></i><span>Available Campaigns</span>
              </a></li>
              <li><a href="#" className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-history">
                <i className="fas fa-history"></i><span>Review History</span>
              </a></li>
              <li><button onClick={() => setShowWalletModal(true)} className="w-full flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-wallet">
                <i className="fas fa-wallet"></i><span>Wallet</span>
              </button></li>
              <li><button onClick={() => setShowReferralModal(true)} className="w-full flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted px-4 py-3 rounded-lg transition-colors" data-testid="nav-referrals">
                <i className="fas fa-users"></i><span>Referrals</span>
              </button></li>
            </ul>
          </nav>
        </aside>
        
        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Dashboard Overview */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-foreground mb-6">Good morning, {(user as any)?.firstName || 'User'}!</h2>
            
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Total Earnings</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-earnings">₹{(user as any)?.totalEarnings || '0'}</p>
                    </div>
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                      <i className="fas fa-rupee-sign text-accent text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Reviews Completed</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-reviews">{(userReviews as any[]).filter((r: any) => r.status === 'approved').length}</p>
                    </div>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <i className="fas fa-star text-primary text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Success Rate</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-success-rate">
                        {(userReviews as any[]).length > 0 
                          ? Math.round(((userReviews as any[]).filter((r: any) => r.status === 'approved').length / (userReviews as any[]).length) * 100)
                          : 0
                        }%
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                      <i className="fas fa-chart-line text-accent text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Pending Reviews</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="stat-pending">{(userReviews as any[]).filter((r: any) => r.status === 'pending').length}</p>
                    </div>
                    <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-clock text-yellow-600 text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
          
          {/* Available Campaigns */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-semibold text-foreground">Available Campaigns</h3>
            </div>
            
            {campaignsLoading ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-card border border-border rounded-xl p-6 h-40"></div>
                  </div>
                ))}
              </div>
            ) : (campaigns as any[]).length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <i className="fas fa-inbox text-muted-foreground text-4xl mb-4"></i>
                  <p className="text-muted-foreground">No campaigns available at the moment. Check back soon!</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {(campaigns as any[]).map((campaign: any) => (
                  <Card key={campaign.id} className="hover:shadow-md transition-shadow" data-testid={`campaign-${campaign.id}`}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex-1">
                          <h4 className="font-semibold text-foreground text-lg mb-2" data-testid={`campaign-title-${campaign.id}`}>{campaign.title}</h4>
                          <p className="text-muted-foreground text-sm mb-3" data-testid={`campaign-description-${campaign.id}`}>{campaign.description}</p>
                          <div className="flex items-center space-x-4 text-sm">
                            <span className="flex items-center text-accent font-medium">
                              <i className="fas fa-rupee-sign mr-1"></i>
                              <span data-testid={`campaign-reward-${campaign.id}`}>₹{campaign.rewardAmount}</span>
                            </span>
                            <span className="text-muted-foreground" data-testid={`campaign-deadline-${campaign.id}`}>
                              {Math.ceil((new Date(campaign.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days left
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <i className="fas fa-users"></i>
                          <span data-testid={`campaign-spots-${campaign.id}`}>{campaign.totalReviewsNeeded - campaign.completedReviews} spots left</span>
                        </div>
                        <Button
                          onClick={() => handleAcceptCampaign(campaign)}
                          data-testid={`button-accept-${campaign.id}`}
                        >
                          Accept
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
          
          {/* Active Reviews */}
          {(userReviews as any[]).length > 0 && (
            <div className="mb-8">
              <h3 className="text-2xl font-semibold text-foreground mb-6">Recent Reviews</h3>
              
              <div className="space-y-4">
                {(userReviews as any[]).slice(0, 3).map((review: any) => (
                  <Card key={review.id} data-testid={`review-${review.id}`}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h4 className="font-medium text-foreground" data-testid={`review-title-${review.id}`}>{review.title}</h4>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              review.status === 'approved' 
                                ? 'bg-accent/10 text-accent' 
                                : review.status === 'pending'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-destructive/10 text-destructive'
                            }`} data-testid={`review-status-${review.id}`}>
                              {review.status.charAt(0).toUpperCase() + review.status.slice(1)}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3" data-testid={`review-date-${review.id}`}>
                            Submitted {new Date(review.submittedAt).toLocaleDateString()}
                          </p>
                        </div>
                        
                        <div className="text-right">
                          <div className="text-lg font-semibold text-accent" data-testid={`review-reward-${review.id}`}>₹{review.rewardAmount}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      <ReviewModal
        isOpen={showReviewModal}
        campaign={selectedCampaign}
        onClose={() => {
          setShowReviewModal(false);
          setSelectedCampaign(null);
        }}
      />

      <WalletModal
        isOpen={showWalletModal}
        onClose={() => setShowWalletModal(false)}
        user={user}
      />

      <ReferralModal
        isOpen={showReferralModal}
        onClose={() => setShowReferralModal(false)}
      />
    </div>
  );
}
