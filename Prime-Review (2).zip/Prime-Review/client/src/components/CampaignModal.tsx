import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCampaignSchema } from "@shared/schema";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const campaignFormSchema = insertCampaignSchema.extend({
  startDate: z.string(),
  endDate: z.string(),
});

interface CampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CampaignModal({ isOpen, onClose }: CampaignModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
  });

  const form = useForm<z.infer<typeof campaignFormSchema>>({
    resolver: zodResolver(campaignFormSchema),
    defaultValues: {
      title: "",
      description: "",
      categoryId: "",
      rewardAmount: "100",
      totalReviewsNeeded: 10,
      requirements: "",
      startDate: "",
      endDate: "",
    },
  });

  const createCampaignMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/campaigns", {
        ...data,
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Success",
        description: "Campaign created successfully!",
      });
      onClose();
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create campaign",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: z.infer<typeof campaignFormSchema>) => {
    createCampaignMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-foreground text-center" data-testid="modal-title">
            Create New Campaign
          </DialogTitle>
          <DialogDescription className="text-center text-muted-foreground">
            Set up your review campaign to connect with potential customers
          </DialogDescription>
        </DialogHeader>
        <div className="p-2">
          
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="title">Campaign Name</Label>
                <Input
                  id="title"
                  placeholder="e.g., Summer Collection Review"
                  {...form.register("title")}
                  data-testid="input-campaign-title"
                />
                {form.formState.errors.title && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.title.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="categoryId">Category</Label>
                <Select onValueChange={(value) => form.setValue("categoryId", value)}>
                  <SelectTrigger data-testid="select-category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {(categories as any[]).map((category: any) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.categoryId && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.categoryId.message}</p>
                )}
              </div>
            </div>
            
            <div>
              <Label htmlFor="description">Campaign Description</Label>
              <Textarea
                id="description"
                rows={4}
                placeholder="Describe what reviewers need to do..."
                {...form.register("description")}
                data-testid="textarea-description"
              />
              {form.formState.errors.description && (
                <p className="text-destructive text-sm mt-1">{form.formState.errors.description.message}</p>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="rewardAmount">Reward per Review (₹)</Label>
                <Input
                  id="rewardAmount"
                  type="number"
                  placeholder="120"
                  min="50"
                  max="150"
                  {...form.register("rewardAmount")}
                  data-testid="input-reward-amount"
                />
                {form.formState.errors.rewardAmount && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.rewardAmount.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="totalReviewsNeeded">Total Reviews Needed</Label>
                <Input
                  id="totalReviewsNeeded"
                  type="number"
                  placeholder="20"
                  {...form.register("totalReviewsNeeded", { valueAsNumber: true })}
                  data-testid="input-reviews-needed"
                />
                {form.formState.errors.totalReviewsNeeded && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.totalReviewsNeeded.message}</p>
                )}
              </div>
              <div>
                <Label>Total Budget</Label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-muted-foreground">₹</span>
                  <Input
                    className="pl-8"
                    value={(parseFloat(form.watch("rewardAmount") || "0") * (form.watch("totalReviewsNeeded") || 0)).toFixed(0)}
                    readOnly
                    data-testid="display-total-budget"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="startDate">Start Date</Label>
                <Input
                  id="startDate"
                  type="datetime-local"
                  {...form.register("startDate")}
                  data-testid="input-start-date"
                />
                {form.formState.errors.startDate && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.startDate.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="endDate">End Date</Label>
                <Input
                  id="endDate"
                  type="datetime-local"
                  {...form.register("endDate")}
                  data-testid="input-end-date"
                />
                {form.formState.errors.endDate && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.endDate.message}</p>
                )}
              </div>
            </div>
            
            <div className="flex justify-between items-center pt-6 border-t border-border">
              <Button 
                type="button"
                variant="ghost" 
                onClick={() => window.location.href = '/'}
                className="flex items-center space-x-2"
                data-testid="button-home"
              >
                <i className="fas fa-home"></i>
                <span>Home</span>
              </Button>
              <div className="flex space-x-4">
                <Button type="button" variant="outline" onClick={onClose} data-testid="button-cancel-campaign">
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createCampaignMutation.isPending}
                  data-testid="button-create-campaign"
                >
                  {createCampaignMutation.isPending ? "Creating..." : "Create Campaign"}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
