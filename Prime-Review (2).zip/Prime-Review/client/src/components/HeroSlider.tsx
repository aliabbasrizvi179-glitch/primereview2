import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";

export default function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const { data: sliders = [] } = useQuery({
    queryKey: ["/api/sliders"],
  });

  // Default sliders if none from backend
  const defaultSliders = [
    {
      id: 1,
      title: "Professional Review Management",
      description: "Connect brands with authentic reviewers. Build trust, increase visibility, grow your business.",
      buttonText: "Get Started Today",
      buttonLink: "/signup",
      backgroundGradient: "from-primary to-primary/80"
    },
    {
      id: 2,
      title: "Earn Money Writing Reviews",
      description: "Turn your opinions into income. Review products and services you love, earn ₹50-₹150 per review.",
      buttonText: "Start Earning",
      buttonLink: "/signup",
      backgroundGradient: "from-accent to-accent/80"
    },
    {
      id: 3,
      title: "Trusted by Thousands",
      description: "Join our secure platform with verified users, transparent payments, and 24/7 support.",
      buttonText: "Learn More",
      buttonLink: "/features",
      backgroundGradient: "from-secondary to-muted"
    }
  ];

  const slidesToUse = (sliders as any[]).length > 0 ? sliders : defaultSliders;

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % (slidesToUse as any[]).length);
    }, 5000);

    return () => clearInterval(interval);
  }, [(slidesToUse as any[]).length]);

  return (
    <div className="slider-container h-96 rounded-2xl shadow-2xl mb-16 relative overflow-hidden" data-testid="hero-slider">
      <div 
        className="slider-track h-full flex transition-transform duration-500 ease-in-out"
        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
      >
        {(slidesToUse as any[]).map((slider: any, index: number) => (
          <div
            key={slider.id}
            className={`w-full h-full flex-shrink-0 bg-gradient-to-r ${
              slider.backgroundGradient || 'from-primary to-primary/80'
            } flex items-center justify-center text-white relative`}
            data-testid={`slide-${index + 1}`}
          >
            <div className="absolute inset-0 bg-black/20"></div>
            <div className="relative z-10 text-center max-w-4xl mx-auto px-6">
              <h2 className="text-5xl font-bold mb-6" data-testid={`slide-title-${index + 1}`}>{slider.title}</h2>
              <p className="text-xl opacity-90 mb-8" data-testid={`slide-description-${index + 1}`}>{slider.description}</p>
              {slider.buttonText && (
                <button 
                  className="bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                  data-testid={`slide-button-${index + 1}`}
                >
                  {slider.buttonText}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {/* Slider Controls */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-3">
        {(slidesToUse as any[]).map((_: any, index: number) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-colors ${
              index === currentSlide ? 'bg-white' : 'bg-white/40 hover:bg-white'
            }`}
            data-testid={`slider-control-${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
