import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertReviewSchema } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { z } from "zod";
import { ObjectUploader } from "./ObjectUploader";
import type { UploadResult } from "@uppy/core";

const reviewFormSchema = insertReviewSchema.extend({
  rating: z.number().min(1).max(5),
});

interface ReviewModalProps {
  isOpen: boolean;
  campaign: any;
  onClose: () => void;
}

export default function ReviewModal({ isOpen, campaign, onClose }: ReviewModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [rating, setRating] = useState(0);
  const [proofImages, setProofImages] = useState<string[]>([]);

  const form = useForm<z.infer<typeof reviewFormSchema>>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      title: "",
      content: "",
      rating: 0,
      campaignId: campaign?.id || "",
      rewardAmount: campaign?.rewardAmount || "0",
      proofImages: [],
    },
  });

  const createReviewMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/reviews", {
        ...data,
        rating,
        proofImages,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Success",
        description: "Review submitted successfully! It will be reviewed by our admin team.",
      });
      onClose();
      form.reset();
      setRating(0);
      setProofImages([]);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit review",
        variant: "destructive",
      });
    },
  });

  const handleGetUploadParameters = async () => {
    const response = await apiRequest("POST", "/api/objects/upload", {});
    const data = await response.json();
    return {
      method: "PUT" as const,
      url: data.uploadURL,
    };
  };

  const handleUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.successful && result.successful.length > 0) {
      for (const file of result.successful) {
        if (file.uploadURL) {
          try {
            const response = await apiRequest("PUT", "/api/review-images", {
              imageURL: file.uploadURL,
            });
            const data = await response.json();
            setProofImages(prev => [...prev, data.objectPath]);
            toast({
              title: "Success",
              description: "Image uploaded successfully",
            });
          } catch (error) {
            toast({
              title: "Error",
              description: "Failed to process uploaded image",
              variant: "destructive",
            });
          }
        }
      }
    }
  };

  const onSubmit = (data: z.infer<typeof reviewFormSchema>) => {
    if (rating === 0) {
      toast({
        title: "Error",
        description: "Please provide a rating",
        variant: "destructive",
      });
      return;
    }

    if (proofImages.length === 0) {
      toast({
        title: "Error",
        description: "Please upload at least one proof screenshot",
        variant: "destructive",
      });
      return;
    }

    createReviewMutation.mutate(data);
  };

  const renderStars = () => {
    return Array.from({ length: 5 }, (_, i) => (
      <button
        key={i}
        type="button"
        onClick={() => setRating(i + 1)}
        className={`text-2xl hover:scale-110 transition-transform ${
          i < rating ? 'text-yellow-400' : 'text-muted-foreground'
        }`}
        data-testid={`star-${i + 1}`}
      >
        {i < rating ? '★' : '☆'}
      </button>
    ));
  };

  if (!campaign) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-2">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-foreground" data-testid="modal-title">Submit Review</h2>
          </div>
          
          {/* Campaign Info */}
          <div className="bg-muted rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-foreground mb-2" data-testid="campaign-info-title">{campaign.title}</h3>
            <p className="text-muted-foreground text-sm" data-testid="campaign-info-description">{campaign.description}</p>
            <div className="flex justify-between items-center mt-3">
              <span className="text-accent font-medium" data-testid="campaign-info-reward">Reward: ₹{campaign.rewardAmount}</span>
              <span className="text-muted-foreground text-sm" data-testid="campaign-info-deadline">
                Due in {Math.ceil((new Date(campaign.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days
              </span>
            </div>
          </div>
          
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <Label htmlFor="title">Review Title</Label>
              <Input
                id="title"
                placeholder="Give your review a catchy title"
                {...form.register("title")}
                data-testid="input-review-title"
              />
              {form.formState.errors.title && (
                <p className="text-destructive text-sm mt-1">{form.formState.errors.title.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="content">Review Content</Label>
              <Textarea
                id="content"
                rows={6}
                placeholder="Write your detailed review here..."
                {...form.register("content")}
                data-testid="textarea-review-content"
              />
              {form.formState.errors.content && (
                <p className="text-destructive text-sm mt-1">{form.formState.errors.content.message}</p>
              )}
            </div>
            
            <div>
              <Label>Rating</Label>
              <div className="flex space-x-2" data-testid="rating-stars">
                {renderStars()}
              </div>
            </div>
            
            <div>
              <Label>Proof Screenshots</Label>
              <div className="space-y-4">
                <ObjectUploader
                  maxNumberOfFiles={5}
                  maxFileSize={10485760} // 10MB
                  onGetUploadParameters={handleGetUploadParameters}
                  onComplete={handleUploadComplete}
                  buttonClassName="w-full"
                >
                  <div className="border-2 border-dashed border-input rounded-lg p-8 text-center bg-background hover:bg-muted/30 transition-colors cursor-pointer">
                    <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-cloud-upload-alt text-muted-foreground text-2xl"></i>
                    </div>
                    <p className="text-muted-foreground mb-2">Click to upload screenshots</p>
                    <p className="text-sm text-muted-foreground">PNG, JPG up to 10MB each</p>
                  </div>
                </ObjectUploader>
                
                {proofImages.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-foreground">Uploaded Images:</p>
                    <div className="space-y-1">
                      {proofImages.map((image, index) => (
                        <p key={index} className="text-sm text-accent" data-testid={`uploaded-image-${index}`}>
                          ✓ Image {index + 1} uploaded successfully
                        </p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex justify-between items-center pt-6 border-t border-border">
              <Button 
                type="button"
                variant="ghost" 
                onClick={() => window.location.href = '/'}
                className="flex items-center space-x-2"
                data-testid="button-home"
              >
                <i className="fas fa-home"></i>
                <span>Home</span>
              </Button>
              <div className="flex space-x-4">
                <Button type="button" variant="outline" onClick={onClose} data-testid="button-cancel-review">
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createReviewMutation.isPending}
                  data-testid="button-submit-review"
                >
                  {createReviewMutation.isPending ? "Submitting..." : "Submit Review"}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
