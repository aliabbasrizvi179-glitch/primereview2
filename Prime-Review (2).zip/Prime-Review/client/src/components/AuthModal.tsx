import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";

interface AuthModalProps {
  isOpen: boolean;
  mode: 'login' | 'signup';
  onClose: () => void;
  onSwitchMode: (mode: 'login' | 'signup') => void;
}

export default function AuthModal({ isOpen, mode, onClose, onSwitchMode }: AuthModalProps) {
  const [selectedRole, setSelectedRole] = useState<'user' | 'brand'>('user');

  const handleLogin = () => {
    window.location.href = '/api/login';
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    // Store selected role in localStorage for after auth redirect
    localStorage.setItem('selectedRole', selectedRole);
    window.location.href = '/api/login';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        {mode === 'login' ? (
          <div className="p-2">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-foreground mb-2" data-testid="auth-title">Welcome Back</h2>
              <p className="text-muted-foreground">Sign in to your account</p>
            </div>
            
            <div className="text-center">
              <Button
                onClick={handleLogin}
                className="w-full mb-4"
                data-testid="button-auth-login"
              >
                Continue with Replit Auth
              </Button>
            </div>
            
            <div className="flex justify-between items-center mt-6">
              <Button 
                variant="ghost" 
                onClick={() => window.location.href = '/'}
                className="flex items-center space-x-2"
                data-testid="button-home"
              >
                <i className="fas fa-home"></i>
                <span>Home</span>
              </Button>
              <p className="text-muted-foreground">Don't have an account? 
                <button onClick={() => onSwitchMode('signup')} className="text-primary hover:text-primary/80 font-medium ml-1" data-testid="link-switch-signup">
                  Sign up
                </button>
              </p>
            </div>
          </div>
        ) : (
          <div className="p-2">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-foreground mb-2" data-testid="auth-title">Create Account</h2>
              <p className="text-muted-foreground">Join ReviewPro today</p>
            </div>
            
            <form onSubmit={handleSignup} className="space-y-6">
              {/* Role Selection */}
              <div>
                <Label className="block text-sm font-medium text-foreground mb-4">Select Your Role</Label>
                <RadioGroup value={selectedRole} onValueChange={(value: 'user' | 'brand') => setSelectedRole(value)}>
                  <div className="grid grid-cols-2 gap-4">
                    <Label className="relative cursor-pointer">
                      <RadioGroupItem value="user" className="sr-only" />
                      <div className={`border-2 rounded-lg p-4 text-center transition-all hover:border-primary/50 ${
                        selectedRole === 'user' ? 'border-primary bg-primary/5' : 'border-input'
                      }`} data-testid="role-user">
                        <i className="fas fa-user text-2xl text-primary mb-2"></i>
                        <div className="font-medium">User</div>
                        <div className="text-sm text-muted-foreground">Write reviews & earn money</div>
                      </div>
                    </Label>
                    
                    <Label className="relative cursor-pointer">
                      <RadioGroupItem value="brand" className="sr-only" />
                      <div className={`border-2 rounded-lg p-4 text-center transition-all hover:border-primary/50 ${
                        selectedRole === 'brand' ? 'border-primary bg-primary/5' : 'border-input'
                      }`} data-testid="role-brand">
                        <i className="fas fa-building text-2xl text-primary mb-2"></i>
                        <div className="font-medium">Brand</div>
                        <div className="text-sm text-muted-foreground">Get authentic reviews</div>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              
              <Button
                type="submit"
                className="w-full"
                data-testid="button-auth-signup"
              >
                Continue with Replit Auth
              </Button>
            </form>
            
            <div className="flex justify-between items-center mt-6">
              <Button 
                variant="ghost" 
                onClick={() => window.location.href = '/'}
                className="flex items-center space-x-2"
                data-testid="button-home"
              >
                <i className="fas fa-home"></i>
                <span>Home</span>
              </Button>
              <p className="text-muted-foreground">Already have an account? 
                <button onClick={() => onSwitchMode('login')} className="text-primary hover:text-primary/80 font-medium ml-1" data-testid="link-switch-login">
                  Sign in
                </button>
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
