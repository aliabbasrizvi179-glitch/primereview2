import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerified: () => void;
  userRole: 'user' | 'brand';
}

export default function VerificationModal({ isOpen, onClose, onVerified, userRole }: VerificationModalProps) {
  const [verificationType, setVerificationType] = useState<'email' | 'phone'>('email');
  const [step, setStep] = useState<'choose' | 'verify'>('choose');
  const [contactInfo, setContactInfo] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sendCodeMutation = useMutation({
    mutationFn: async () => {
      const endpoint = verificationType === 'email' ? '/api/verification/send-email' : '/api/verification/send-sms';
      const payload = verificationType === 'email' ? { email: contactInfo } : { phone: contactInfo };
      const response = await apiRequest("POST", endpoint, payload);
      return response.json();
    },
    onSuccess: () => {
      setStep('verify');
      toast({
        title: "Verification code sent",
        description: `Please check your ${verificationType === 'email' ? 'email' : 'phone'} for the verification code.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send verification code",
        variant: "destructive",
      });
    },
  });

  const verifyCodeMutation = useMutation({
    mutationFn: async () => {
      const endpoint = verificationType === 'email' ? '/api/verification/verify-email' : '/api/verification/verify-phone';
      const payload = verificationType === 'email' 
        ? { email: contactInfo, code: verificationCode }
        : { phone: contactInfo, code: verificationCode };
      const response = await apiRequest("POST", endpoint, payload);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Verification successful",
        description: `Your ${verificationType === 'email' ? 'email' : 'phone number'} has been verified successfully!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      onVerified();
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Verification failed",
        description: error.message || "Invalid verification code",
        variant: "destructive",
      });
    },
  });

  const handleSendCode = () => {
    if (!contactInfo.trim()) {
      toast({
        title: "Error",
        description: `Please enter your ${verificationType === 'email' ? 'Google email' : 'phone number'}`,
        variant: "destructive",
      });
      return;
    }

    if (verificationType === 'email' && !contactInfo.includes('@gmail.com')) {
      toast({
        title: "Error",
        description: "Please enter a valid Gmail address",
        variant: "destructive",
      });
      return;
    }

    if (verificationType === 'phone' && !/^\+?[\d\s-()]+$/.test(contactInfo)) {
      toast({
        title: "Error",
        description: "Please enter a valid phone number",
        variant: "destructive",
      });
      return;
    }

    sendCodeMutation.mutate();
  };

  const handleVerifyCode = () => {
    if (!verificationCode.trim()) {
      toast({
        title: "Error",
        description: "Please enter the verification code",
        variant: "destructive",
      });
      return;
    }

    verifyCodeMutation.mutate();
  };

  const resetModal = () => {
    setStep('choose');
    setContactInfo('');
    setVerificationCode('');
    setVerificationType('email');
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogTitle className="text-2xl font-bold text-foreground mb-2">
          {step === 'choose' ? 'Verify Your Account' : 'Enter Verification Code'}
        </DialogTitle>
        <DialogDescription className="text-muted-foreground mb-6">
          {step === 'choose' 
            ? `As a ${userRole}, you must verify either your Google email or phone number to continue.`
            : `We've sent a verification code to your ${verificationType === 'email' ? 'email' : 'phone number'}.`
          }
        </DialogDescription>

        {step === 'choose' ? (
          <div className="space-y-6">
            {/* Verification Type Selection */}
            <div>
              <Label className="block text-sm font-medium text-foreground mb-4">
                Choose verification method:
              </Label>
              <RadioGroup 
                value={verificationType} 
                onValueChange={(value: 'email' | 'phone') => setVerificationType(value)}
              >
                <div className="space-y-4">
                  <Label className="relative cursor-pointer">
                    <RadioGroupItem value="email" className="sr-only" />
                    <div className={`border-2 rounded-lg p-4 transition-all hover:border-primary/50 ${
                      verificationType === 'email' ? 'border-primary bg-primary/5' : 'border-input'
                    }`} data-testid="verification-email">
                      <div className="flex items-center space-x-3">
                        <i className="fab fa-google text-2xl text-primary"></i>
                        <div>
                          <div className="font-medium">Google Email</div>
                          <div className="text-sm text-muted-foreground">Verify with your Gmail account</div>
                        </div>
                      </div>
                    </div>
                  </Label>
                  
                  <Label className="relative cursor-pointer">
                    <RadioGroupItem value="phone" className="sr-only" />
                    <div className={`border-2 rounded-lg p-4 transition-all hover:border-primary/50 ${
                      verificationType === 'phone' ? 'border-primary bg-primary/5' : 'border-input'
                    }`} data-testid="verification-phone">
                      <div className="flex items-center space-x-3">
                        <i className="fas fa-mobile-alt text-2xl text-primary"></i>
                        <div>
                          <div className="font-medium">Phone Number</div>
                          <div className="text-sm text-muted-foreground">Verify with SMS code</div>
                        </div>
                      </div>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Contact Info Input */}
            <div>
              <Label className="block text-sm font-medium text-foreground mb-2">
                {verificationType === 'email' ? 'Gmail Address' : 'Phone Number'}
              </Label>
              <Input
                type={verificationType === 'email' ? 'email' : 'tel'}
                placeholder={verificationType === 'email' ? 'your.email@gmail.com' : '+1 (555) 123-4567'}
                value={contactInfo}
                onChange={(e) => setContactInfo(e.target.value)}
                data-testid={`input-${verificationType}`}
              />
            </div>

            <Button
              onClick={handleSendCode}
              className="w-full"
              disabled={sendCodeMutation.isPending}
              data-testid="button-send-code"
            >
              {sendCodeMutation.isPending ? 'Sending...' : 'Send Verification Code'}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm text-muted-foreground">
                Code sent to: <span className="font-medium text-foreground">{contactInfo}</span>
              </p>
            </div>

            <div>
              <Label className="block text-sm font-medium text-foreground mb-2">
                Verification Code
              </Label>
              <Input
                type="text"
                placeholder="Enter 6-digit code"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                maxLength={6}
                data-testid="input-verification-code"
              />
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleVerifyCode}
                className="w-full"
                disabled={verifyCodeMutation.isPending}
                data-testid="button-verify-code"
              >
                {verifyCodeMutation.isPending ? 'Verifying...' : 'Verify Code'}
              </Button>

              <Button
                variant="outline"
                onClick={() => setStep('choose')}
                className="w-full"
                data-testid="button-back"
              >
                Back to Choose Method
              </Button>
            </div>
          </div>
        )}

        <div className="flex justify-center mt-6">
          <Button 
            variant="ghost" 
            onClick={() => window.location.href = '/'}
            className="flex items-center space-x-2"
            data-testid="button-home"
          >
            <i className="fas fa-home"></i>
            <span>Home</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}