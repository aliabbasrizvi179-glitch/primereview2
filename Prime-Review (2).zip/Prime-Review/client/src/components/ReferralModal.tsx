import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ReferralModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ReferralModal({ isOpen, onClose }: ReferralModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);

  // Fetch referral code
  const { data: referralData } = useQuery({
    queryKey: ["/api/referrals/my-code"],
    enabled: isOpen,
  });

  // Fetch referral stats
  const { data: stats } = useQuery({
    queryKey: ["/api/referrals/stats"],
    enabled: isOpen,
  });

  // Fetch referral history
  const { data: history = [] } = useQuery({
    queryKey: ["/api/referrals/history"],
    enabled: isOpen,
  });

  const referralCode = (referralData as any)?.referralCode;
  const referralLink = referralCode ? `${window.location.origin}?ref=${referralCode}` : '';

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast({
        title: "Copied!",
        description: `${type} copied to clipboard`,
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please copy manually",
        variant: "destructive",
      });
    }
  };

  const shareViaWhatsApp = () => {
    const message = `🎉 Join primereview and start earning money by writing reviews! Use my referral code: ${referralCode}\n\n💰 Earn ₹25-₹150 per review\n🎁 Get ₹25 bonus when you sign up with my code\n\nSign up here: ${referralLink}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const shareViaEmail = () => {
    const subject = "Earn Money Writing Reviews - Join primereview!";
    const body = `Hi!\n\nI wanted to share an amazing opportunity with you. I've been earning money by writing reviews on primereview and thought you might be interested too!\n\n💰 Earn ₹25-₹150 per review\n🎁 Get ₹25 bonus when you sign up with my referral code: ${referralCode}\n\nHere's the link to join: ${referralLink}\n\nIt's completely free to join and you can start earning right away!\n\nBest regards`;
    
    const emailUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(emailUrl);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            <i className="fas fa-users mr-2 text-primary"></i>
            Referral Program
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="share">Share & Earn</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-primary mb-2" data-testid="total-referrals">
                    {(stats as any)?.totalReferrals || 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Total Referrals</div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-accent mb-2" data-testid="total-earnings">
                    ₹{(stats as any)?.totalEarnings || '0'}
                  </div>
                  <div className="text-sm text-muted-foreground">Total Earned</div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-yellow-600 mb-2" data-testid="pending-payouts">
                    ₹{(stats as any)?.pendingPayouts || '0'}
                  </div>
                  <div className="text-sm text-muted-foreground">Pending</div>
                </CardContent>
              </Card>
            </div>

            {/* How it Works */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">
                  <i className="fas fa-info-circle mr-2 text-primary"></i>
                  How Referrals Work
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-share-alt text-primary"></i>
                    </div>
                    <h4 className="font-medium mb-2">Share Your Code</h4>
                    <p className="text-sm text-muted-foreground">Share your unique referral code with friends and family</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-user-plus text-accent"></i>
                    </div>
                    <h4 className="font-medium mb-2">Friend Joins</h4>
                    <p className="text-sm text-muted-foreground">They sign up using your referral code</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-coins text-yellow-600"></i>
                    </div>
                    <h4 className="font-medium mb-2">You Both Earn</h4>
                    <p className="text-sm text-muted-foreground">You get ₹25 and they get ₹25 bonus</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="share" className="space-y-6">
            {/* Your Referral Code */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">
                  <i className="fas fa-code mr-2 text-primary"></i>
                  Your Referral Code
                </h3>
                <div className="flex items-center space-x-2 mb-4">
                  <Input
                    value={referralCode || "Loading..."}
                    readOnly
                    className="font-mono text-lg"
                    data-testid="referral-code-input"
                  />
                  <Button
                    onClick={() => copyToClipboard(referralCode || '', 'Referral code')}
                    disabled={!referralCode}
                    data-testid="copy-code-button"
                  >
                    <i className={`fas ${copied ? 'fa-check' : 'fa-copy'} mr-2`}></i>
                    {copied ? 'Copied!' : 'Copy'}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Referral Link */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">
                  <i className="fas fa-link mr-2 text-primary"></i>
                  Your Referral Link
                </h3>
                <div className="flex items-center space-x-2 mb-4">
                  <Input
                    value={referralLink || "Loading..."}
                    readOnly
                    className="text-sm"
                    data-testid="referral-link-input"
                  />
                  <Button
                    onClick={() => copyToClipboard(referralLink, 'Referral link')}
                    disabled={!referralLink}
                    data-testid="copy-link-button"
                  >
                    <i className={`fas ${copied ? 'fa-check' : 'fa-copy'} mr-2`}></i>
                    {copied ? 'Copied!' : 'Copy'}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Share Options */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">
                  <i className="fas fa-share-alt mr-2 text-primary"></i>
                  Share Your Code
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button
                    onClick={shareViaWhatsApp}
                    disabled={!referralCode}
                    className="bg-green-500 hover:bg-green-600 text-white"
                    data-testid="share-whatsapp"
                  >
                    <i className="fab fa-whatsapp mr-2"></i>
                    Share via WhatsApp
                  </Button>
                  <Button
                    onClick={shareViaEmail}
                    disabled={!referralCode}
                    variant="outline"
                    data-testid="share-email"
                  >
                    <i className="fas fa-envelope mr-2"></i>
                    Share via Email
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">
                  <i className="fas fa-history mr-2 text-primary"></i>
                  Referral History
                </h3>
                
                {(history as any[]).length === 0 ? (
                  <div className="text-center py-8">
                    <i className="fas fa-users text-muted-foreground text-4xl mb-4"></i>
                    <p className="text-muted-foreground">No referrals yet. Start sharing your code!</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {(history as any[]).map((referral: any) => (
                      <div key={referral.id} className="flex justify-between items-center p-4 border rounded-lg" data-testid={`referral-item-${referral.id}`}>
                        <div>
                          <div className="font-medium">Referral #{referral.id.substr(0, 8)}</div>
                          <div className="text-sm text-muted-foreground">
                            {new Date(referral.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-accent">₹{referral.rewardAmount}</div>
                          <div className={`text-xs px-2 py-1 rounded ${
                            referral.isPaid 
                              ? 'bg-accent/10 text-accent' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {referral.isPaid ? 'Paid' : 'Pending'}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between items-center pt-4">
          <Button 
            variant="ghost" 
            onClick={() => window.location.href = '/'}
            className="flex items-center space-x-2"
            data-testid="button-home"
          >
            <i className="fas fa-home"></i>
            <span>Home</span>
          </Button>
          <Button variant="outline" onClick={onClose} data-testid="close-referral-modal">
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}