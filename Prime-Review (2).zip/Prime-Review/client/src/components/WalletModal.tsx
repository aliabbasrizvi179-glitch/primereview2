import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
}

export default function WalletModal({ isOpen, onClose, user }: WalletModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [withdrawalMethod, setWithdrawalMethod] = useState<'upi' | 'bank'>('upi');

  const { data: payments = [] } = useQuery({
    queryKey: ["/api/payments/user", user?.id],
    enabled: !!user?.id && isOpen,
  });

  const form = useForm({
    defaultValues: {
      amount: "",
      paymentDetails: "",
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/payments/withdraw", {
        amount: data.amount,
        paymentMethod: withdrawalMethod,
        paymentDetails: data.paymentDetails,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      toast({
        title: "Success",
        description: "Withdrawal request submitted successfully!",
      });
      form.reset();
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process withdrawal",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    const amount = parseFloat(data.amount);
    const currentBalance = parseFloat(user?.walletBalance || '0');

    if (amount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    if (amount < 100) {
      toast({
        title: "Error",
        description: "Minimum withdrawal amount is ₹100",
        variant: "destructive",
      });
      return;
    }

    if (amount > currentBalance) {
      toast({
        title: "Error",
        description: "Insufficient balance",
        variant: "destructive",
      });
      return;
    }

    if (!data.paymentDetails.trim()) {
      toast({
        title: "Error",
        description: "Please enter payment details",
        variant: "destructive",
      });
      return;
    }

    withdrawMutation.mutate(data);
  };

  const recentPayments = (payments as any[]).slice(0, 5);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <div className="p-2">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-foreground" data-testid="wallet-title">Wallet</h2>
          </div>
          
          {/* Wallet Balance */}
          <div className="bg-gradient-to-r from-accent to-accent/80 rounded-xl p-6 text-white text-center mb-6">
            <p className="text-accent-foreground/80 mb-2">Available Balance</p>
            <p className="text-4xl font-bold" data-testid="wallet-balance">₹{user?.walletBalance || '0'}</p>
          </div>
          
          {/* Withdrawal Form */}
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <Label htmlFor="amount">Withdrawal Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-3 text-muted-foreground">₹</span>
                <Input
                  id="amount"
                  type="number"
                  className="pl-8"
                  placeholder="0"
                  min="100"
                  max={user?.walletBalance || "0"}
                  {...form.register("amount")}
                  data-testid="input-withdrawal-amount"
                />
              </div>
              <p className="text-sm text-muted-foreground mt-1">Minimum withdrawal: ₹100</p>
            </div>
            
            <div>
              <Label>Withdrawal Method</Label>
              <RadioGroup value={withdrawalMethod} onValueChange={(value: 'upi' | 'bank') => setWithdrawalMethod(value)}>
                <div className="grid grid-cols-2 gap-4">
                  <Label className="relative cursor-pointer">
                    <RadioGroupItem value="upi" className="sr-only" />
                    <div className={`border-2 rounded-lg p-4 text-center transition-all hover:border-primary/50 ${
                      withdrawalMethod === 'upi' ? 'border-primary bg-primary/5' : 'border-input'
                    }`} data-testid="method-upi">
                      <i className="fas fa-mobile-alt text-2xl text-primary mb-2"></i>
                      <div className="font-medium">UPI</div>
                    </div>
                  </Label>
                  
                  <Label className="relative cursor-pointer">
                    <RadioGroupItem value="bank" className="sr-only" />
                    <div className={`border-2 rounded-lg p-4 text-center transition-all hover:border-primary/50 ${
                      withdrawalMethod === 'bank' ? 'border-primary bg-primary/5' : 'border-input'
                    }`} data-testid="method-bank">
                      <i className="fas fa-university text-2xl text-primary mb-2"></i>
                      <div className="font-medium">Bank Transfer</div>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>
            
            <div>
              <Label htmlFor="paymentDetails">
                {withdrawalMethod === 'upi' ? 'UPI ID' : 'Account Details'}
              </Label>
              <Input
                id="paymentDetails"
                placeholder={withdrawalMethod === 'upi' ? 'user@paytm' : 'Account Number, IFSC Code'}
                {...form.register("paymentDetails")}
                data-testid="input-payment-details"
              />
            </div>
            
            <div className="flex justify-between items-center pt-6 border-t border-border">
              <Button 
                type="button"
                variant="ghost" 
                onClick={() => window.location.href = '/'}
                className="flex items-center space-x-2"
                data-testid="button-home"
              >
                <i className="fas fa-home"></i>
                <span>Home</span>
              </Button>
              <div className="flex space-x-4">
                <Button type="button" variant="outline" onClick={onClose} data-testid="button-cancel-withdrawal">
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={withdrawMutation.isPending}
                  data-testid="button-withdraw-funds"
                >
                  {withdrawMutation.isPending ? "Processing..." : "Withdraw Funds"}
                </Button>
              </div>
            </div>
          </form>

          {/* Recent Transactions */}
          {recentPayments.length > 0 && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-foreground mb-4">Recent Transactions</h3>
              <div className="space-y-2">
                {recentPayments.map((payment: any) => (
                  <Card key={payment.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-foreground capitalize" data-testid={`payment-type-${payment.id}`}>
                            {payment.type.replace('_', ' ')}
                          </p>
                          <p className="text-sm text-muted-foreground" data-testid={`payment-date-${payment.id}`}>
                            {new Date(payment.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className={`font-semibold ${
                            payment.type === 'withdrawal' ? 'text-destructive' : 'text-accent'
                          }`} data-testid={`payment-amount-${payment.id}`}>
                            {payment.type === 'withdrawal' ? '-' : '+'}₹{payment.amount}
                          </p>
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            payment.status === 'completed' 
                              ? 'bg-accent/10 text-accent'
                              : payment.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-destructive/10 text-destructive'
                          }`} data-testid={`payment-status-${payment.id}`}>
                            {payment.status}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
