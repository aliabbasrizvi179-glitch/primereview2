import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useEffect } from "react";

export function useAuth() {
  const queryClient = useQueryClient();
  
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    queryFn: async () => {
      try {
        const response = await fetch("/api/auth/user", {
          credentials: "include",
        });
        
        if (response.status === 401) {
          return null; // Not authenticated, return null without throwing
        }
        
        if (!response.ok) {
          throw new Error(`${response.status}: ${response.statusText}`);
        }
        
        return await response.json();
      } catch (error) {
        return null; // Return null on any error
      }
    },
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchInterval: false,
  });

  const setRoleMutation = useMutation({
    mutationFn: async (role: string) => {
      const response = await apiRequest("PUT", "/api/auth/role", { role });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      localStorage.removeItem('selectedRole');
    },
  });

  // Handle role assignment after authentication
  useEffect(() => {
    if (user && !isLoading) {
      const selectedRole = localStorage.getItem('selectedRole');
      if (selectedRole && (selectedRole === 'user' || selectedRole === 'brand')) {
        // Only set role if user doesn't already have the correct role
        if (!user.role || user.role !== selectedRole) {
          setRoleMutation.mutate(selectedRole);
        } else {
          // Clear localStorage if role is already correct
          localStorage.removeItem('selectedRole');
        }
      }
    }
  }, [user, isLoading, setRoleMutation]);

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
  };
}
