# Review Business Web App

## Overview

This is a professional review business web application with a three-tier role system: Users, Brands, and Admins. The platform connects brands seeking authentic reviews with users willing to provide them in exchange for monetary rewards. The application features campaign management, review submission with proof verification, wallet systems, and comprehensive admin controls for managing the entire ecosystem.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite for build tooling
- **UI Library**: Shadcn/UI components with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack React Query for server state and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with role-based access control
- **File Upload**: Uppy with AWS S3 integration for proof image uploads
- **Session Management**: Express sessions with PostgreSQL storage

### Database Architecture
- **Primary Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Design**: 
  - Users table with role-based permissions (user, brand, admin)
  - Campaigns table for brand-created review requests
  - Reviews table with approval workflow and proof verification
  - Categories table for pricing tiers (₹50-₹150 per review)
  - Payments table for wallet transactions and withdrawals
  - Notifications and sliders tables for dynamic content

### Authentication & Authorization
- **Provider**: Replit Auth with OpenID Connect
- **Session Strategy**: Server-side sessions with PostgreSQL storage
- **Access Control**: Role-based permissions enforced at API level
- **Security**: HTTPS-only cookies, CSRF protection, authenticated file access

### File Storage & Management
- **Storage**: Google Cloud Storage with object-level ACL policies
- **Upload Flow**: Client-side Uppy dashboard → presigned URLs → direct S3 upload
- **Access Control**: Custom ACL system with user-based permissions
- **Security**: Authenticated access to all uploaded proof images

## External Dependencies

### Cloud Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Google Cloud Storage**: Object storage for review proof images
- **Replit Auth**: Authentication service with OIDC integration

### Payment Integration
- **Planned Integrations**: Razorpay, UPI, and Stripe for wallet funding and withdrawals
- **Wallet System**: Internal credit system with withdrawal capabilities

### Development Tools
- **Replit Platform**: Development environment with built-in deployment
- **Vite**: Fast development server and build tool
- **ESBuild**: Production bundling for server code

### Third-Party Libraries
- **UI Components**: Comprehensive Radix UI component library
- **File Upload**: Uppy ecosystem for robust file handling
- **Validation**: Zod for runtime type validation
- **Forms**: React Hook Form for performant form management