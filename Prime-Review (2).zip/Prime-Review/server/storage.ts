import {
  users,
  campaigns,
  reviews,
  payments,
  categories,
  sliders,
  notifications,
  referrals,
  fraudDetection,
  rateLimits,
  type User,
  type UpsertUser,
  type Campaign,
  type InsertCampaign,
  type Review,
  type InsertReview,
  type Payment,
  type InsertPayment,
  type Category,
  type Slider,
  type InsertSlider,
  type Notification,
  type InsertNotification,
  type Referral,
  type InsertReferral,
  type FraudDetection,
  type InsertFraudDetection,
  type RateLimit,
  type InsertRateLimit,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // User management
  getAllUsers(): Promise<User[]>;
  getAllBrands(): Promise<User[]>;
  updateUserStatus(id: string, status: 'active' | 'blocked' | 'pending'): Promise<void>;
  updateUserRole(id: string, role: 'user' | 'brand' | 'admin'): Promise<void>;
  updateUserWallet(id: string, amount: string): Promise<void>;

  // Verification operations
  setEmailVerificationCode(userId: string, email: string, code: string): Promise<void>;
  setPhoneVerificationCode(userId: string, phone: string, code: string): Promise<void>;
  verifyEmail(userId: string, email: string, code: string): Promise<boolean>;
  verifyPhone(userId: string, phone: string, code: string): Promise<boolean>;
  updateAccountVerificationStatus(userId: string): Promise<void>;
  
  // Campaign operations
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  getCampaign(id: string): Promise<Campaign | undefined>;
  getCampaignsByBrand(brandId: string): Promise<Campaign[]>;
  getActiveCampaigns(): Promise<Campaign[]>;
  getAllCampaigns(): Promise<Campaign[]>;
  updateCampaign(id: string, updates: Partial<Campaign>): Promise<void>;
  updateCampaignStatus(id: string, status: 'active' | 'paused' | 'completed' | 'cancelled'): Promise<void>;
  
  // Review operations
  createReview(review: InsertReview): Promise<Review>;
  getReview(id: string): Promise<Review | undefined>;
  getReviewsByUser(userId: string): Promise<Review[]>;
  getReviewsByCampaign(campaignId: string): Promise<Review[]>;
  getPendingReviews(): Promise<Review[]>;
  updateReviewStatus(id: string, status: 'approved' | 'declined', adminNotes?: string): Promise<void>;
  
  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByUser(userId: string): Promise<Payment[]>;
  getAllPayments(): Promise<Payment[]>;
  updatePaymentStatus(id: string, status: 'completed' | 'failed'): Promise<void>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  createCategory(name: string, description: string, minPrice: string, maxPrice: string): Promise<Category>;
  updateCategory(id: string, updates: Partial<Category>): Promise<void>;
  
  // Slider operations
  getSliders(): Promise<Slider[]>;
  updateSlider(id: string, slider: InsertSlider): Promise<void>;
  
  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  markNotificationRead(id: string): Promise<void>;
  
  // Analytics
  getDashboardStats(): Promise<{
    totalUsers: number;
    totalBrands: number;
    totalReviews: number;
    totalRevenue: string;
    pendingReviews: number;
  }>;
  
  // Referral operations
  generateReferralCode(userId: string): Promise<string>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  getReferralsByUser(userId: string): Promise<Referral[]>;
  getReferralStats(userId: string): Promise<{
    totalReferrals: number;
    totalEarnings: string;
    pendingPayouts: string;
  }>;
  processReferralReward(referralId: string): Promise<void>;
  validateReferralCode(code: string): Promise<User | null>;
  
  // System settings
  getSystemSettings(): Promise<Record<string, any> | undefined>;
  updateSystemSettings(type: string, settings: Record<string, any>): Promise<void>;

  // Fraud detection operations
  createFraudDetection(fraudData: InsertFraudDetection): Promise<FraudDetection>;
  getFraudDetectionByUser(userId: string): Promise<FraudDetection[]>;
  getAllFraudDetection(): Promise<FraudDetection[]>;
  updateFraudDetectionStatus(id: string, status: string): Promise<void>;

  // Rate limiting operations
  createRateLimit(rateLimitData: InsertRateLimit): Promise<RateLimit>;
  getRateLimitByIdentifier(identifier: string, action: string): Promise<RateLimit | undefined>;
  updateRateLimit(id: string, count: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }
  
  async updateUserStatus(id: string, status: 'active' | 'blocked' | 'pending'): Promise<void> {
    await db.update(users).set({ status, updatedAt: new Date() }).where(eq(users.id, id));
  }
  
  async getAllBrands(): Promise<User[]> {
    return db.select().from(users).where(eq(users.role, 'brand')).orderBy(desc(users.createdAt));
  }
  
  async updateUserRole(id: string, role: 'user' | 'brand' | 'admin'): Promise<void> {
    await db.update(users).set({ role, updatedAt: new Date() }).where(eq(users.id, id));
  }
  
  async updateUserWallet(id: string, amount: string): Promise<void> {
    await db.update(users).set({ walletBalance: amount, updatedAt: new Date() }).where(eq(users.id, id));
  }

  async updateUserProfile(id: string, profileData: { firstName?: string; lastName?: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...profileData,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    
    if (!user) {
      throw new Error("User not found");
    }
    return user;
  }

  // Campaign operations
  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db.insert(campaigns).values(campaign).returning();
    return newCampaign;
  }
  
  async getCampaign(id: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign;
  }
  
  async getCampaignsByBrand(brandId: string): Promise<Campaign[]> {
    return db.select().from(campaigns).where(eq(campaigns.brandId, brandId)).orderBy(desc(campaigns.createdAt));
  }
  
  async getActiveCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns)
      .where(and(
        eq(campaigns.status, 'active'),
        sql`${campaigns.endDate} > NOW()`
      ))
      .orderBy(desc(campaigns.createdAt));
  }
  
  async updateCampaign(id: string, updates: Partial<Campaign>): Promise<void> {
    await db.update(campaigns).set({ ...updates, updatedAt: new Date() }).where(eq(campaigns.id, id));
  }
  
  async getAllCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns).orderBy(desc(campaigns.createdAt));
  }
  
  async updateCampaignStatus(id: string, status: 'active' | 'paused' | 'completed' | 'cancelled'): Promise<void> {
    await db.update(campaigns).set({ status, updatedAt: new Date() }).where(eq(campaigns.id, id));
  }

  // Review operations
  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }
  
  async getReview(id: string): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    return review;
  }
  
  async getReviewsByUser(userId: string): Promise<Review[]> {
    return db.select().from(reviews).where(eq(reviews.userId, userId)).orderBy(desc(reviews.submittedAt));
  }
  
  async getReviewsByCampaign(campaignId: string): Promise<Review[]> {
    return db.select().from(reviews).where(eq(reviews.campaignId, campaignId)).orderBy(desc(reviews.submittedAt));
  }
  
  async getPendingReviews(): Promise<Review[]> {
    return db.select().from(reviews).where(eq(reviews.status, 'pending')).orderBy(asc(reviews.submittedAt));
  }
  
  async updateReviewStatus(id: string, status: 'approved' | 'declined', adminNotes?: string): Promise<void> {
    await db.update(reviews).set({ 
      status, 
      adminNotes,
      reviewedAt: new Date()
    }).where(eq(reviews.id, id));
  }

  // Payment operations
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }
  
  async getPaymentsByUser(userId: string): Promise<Payment[]> {
    return db.select().from(payments).where(eq(payments.userId, userId)).orderBy(desc(payments.createdAt));
  }
  
  async updatePaymentStatus(id: string, status: 'completed' | 'failed'): Promise<void> {
    await db.update(payments).set({ 
      status, 
      processedAt: new Date()
    }).where(eq(payments.id, id));
  }
  
  async getAllPayments(): Promise<Payment[]> {
    return db.select().from(payments).orderBy(desc(payments.createdAt));
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.name));
  }
  
  async createCategory(name: string, description: string, minPrice: string, maxPrice: string): Promise<Category> {
    const [category] = await db.insert(categories).values({
      name,
      description,
      minPrice,
      maxPrice,
    }).returning();
    return category;
  }
  
  async updateCategory(id: string, updates: Partial<Category>): Promise<void> {
    await db.update(categories).set(updates).where(eq(categories.id, id));
  }

  // Slider operations
  async getSliders(): Promise<Slider[]> {
    return db.select().from(sliders).where(eq(sliders.isActive, true)).orderBy(asc(sliders.position));
  }
  
  async updateSlider(id: string, slider: InsertSlider): Promise<void> {
    await db.update(sliders).set({ ...slider, updatedAt: new Date() }).where(eq(sliders.id, id));
  }

  // Notification operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }
  
  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
  }
  
  async markNotificationRead(id: string): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }

  // Analytics
  async getDashboardStats(): Promise<{
    totalUsers: number;
    totalBrands: number;
    totalReviews: number;
    totalRevenue: string;
    pendingReviews: number;
  }> {
    const [totalUsers] = await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, 'user'));
    const [totalBrands] = await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, 'brand'));
    const [totalReviews] = await db.select({ count: sql<number>`count(*)` }).from(reviews);
    const [pendingReviews] = await db.select({ count: sql<number>`count(*)` }).from(reviews).where(eq(reviews.status, 'pending'));
    const [revenueResult] = await db.select({ 
      total: sql<string>`COALESCE(SUM(amount), '0')` 
    }).from(payments).where(eq(payments.type, 'deposit'));

    return {
      totalUsers: totalUsers.count,
      totalBrands: totalBrands.count,
      totalReviews: totalReviews.count,
      totalRevenue: revenueResult.total,
      pendingReviews: pendingReviews.count,
    };
  }
  
  // Referral operations
  async generateReferralCode(userId: string): Promise<string> {
    // Generate a unique referral code
    const code = `REF${userId.substr(0, 4).toUpperCase()}${Date.now().toString(36).toUpperCase()}`;
    
    // Update user with referral code
    await db.update(users).set({ 
      referralCode: code,
      updatedAt: new Date() 
    }).where(eq(users.id, userId));
    
    return code;
  }
  
  async createReferral(referral: InsertReferral): Promise<Referral> {
    const [newReferral] = await db.insert(referrals).values(referral).returning();
    return newReferral;
  }
  
  async getReferralsByUser(userId: string): Promise<Referral[]> {
    return db.select().from(referrals)
      .where(eq(referrals.referrerId, userId))
      .orderBy(desc(referrals.createdAt));
  }
  
  async getReferralStats(userId: string): Promise<{
    totalReferrals: number;
    totalEarnings: string;
    pendingPayouts: string;
  }> {
    const [totalCount] = await db.select({ count: sql<number>`count(*)` })
      .from(referrals)
      .where(eq(referrals.referrerId, userId));
    
    const [totalEarnings] = await db.select({ 
      total: sql<string>`COALESCE(SUM(reward_amount), '0')` 
    }).from(referrals)
      .where(and(eq(referrals.referrerId, userId), eq(referrals.isPaid, true)));
    
    const [pendingPayouts] = await db.select({ 
      total: sql<string>`COALESCE(SUM(reward_amount), '0')` 
    }).from(referrals)
      .where(and(eq(referrals.referrerId, userId), eq(referrals.isPaid, false)));

    return {
      totalReferrals: totalCount.count,
      totalEarnings: totalEarnings.total,
      pendingPayouts: pendingPayouts.total,
    };
  }
  
  async processReferralReward(referralId: string): Promise<void> {
    // Mark referral as paid and update user wallet
    const [referral] = await db.select().from(referrals).where(eq(referrals.id, referralId));
    if (!referral) return;
    
    // Update referral as paid
    await db.update(referrals).set({ 
      isPaid: true,
      paidAt: new Date()
    }).where(eq(referrals.id, referralId));
    
    // Add reward to referrer's wallet
    const [referrer] = await db.select().from(users).where(eq(users.id, referral.referrerId));
    if (referrer) {
      const newBalance = (parseFloat(referrer.walletBalance || '0') + parseFloat(referral.rewardAmount)).toString();
      await db.update(users).set({ 
        walletBalance: newBalance,
        updatedAt: new Date()
      }).where(eq(users.id, referral.referrerId));
    }
  }
  
  async validateReferralCode(code: string): Promise<User | null> {
    const [user] = await db.select().from(users).where(eq(users.referralCode, code));
    return user || null;
  }

  // System settings operations
  async getSystemSettings(): Promise<Record<string, any> | undefined> {
    // In a real implementation, this could be a separate settings table
    // For now, return default system settings
    return {
      platformName: 'primereview',
      adminEmail: 'admin@primereview.com',
      minReviewAmount: 50,
      maxReviewAmount: 150,
      platformFee: 5,
      minWithdrawal: 500,
      processingFee: 10,
      referralReward: 25, // ₹25 for each successful referral
    };
  }
  
  async updateSystemSettings(type: string, settings: Record<string, any>): Promise<void> {
    // In a real implementation, this would update a settings table
    // For now, we'll just log the settings update
    console.log(`Updating ${type} settings:`, settings);
  }

  // Verification operations
  async setEmailVerificationCode(userId: string, email: string, code: string): Promise<void> {
    const expiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now
    await db.update(users).set({
      googleEmail: email,
      emailVerificationCode: code,
      verificationCodeExpiry: expiry,
      updatedAt: new Date()
    }).where(eq(users.id, userId));
  }

  async setPhoneVerificationCode(userId: string, phone: string, code: string): Promise<void> {
    const expiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now
    await db.update(users).set({
      phone: phone,
      phoneVerificationCode: code,
      verificationCodeExpiry: expiry,
      updatedAt: new Date()
    }).where(eq(users.id, userId));
  }

  async verifyEmail(userId: string, email: string, code: string): Promise<boolean> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    
    if (!user || !user.emailVerificationCode || !user.verificationCodeExpiry) {
      return false;
    }

    const now = new Date();
    if (now > user.verificationCodeExpiry) {
      return false; // Code expired
    }

    if (user.emailVerificationCode === code && user.googleEmail === email) {
      await db.update(users).set({
        isEmailVerified: true,
        emailVerificationCode: null,
        verificationCodeExpiry: null,
        updatedAt: new Date()
      }).where(eq(users.id, userId));
      
      await this.updateAccountVerificationStatus(userId);
      return true;
    }

    return false;
  }

  async verifyPhone(userId: string, phone: string, code: string): Promise<boolean> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    
    if (!user || !user.phoneVerificationCode || !user.verificationCodeExpiry) {
      return false;
    }

    const now = new Date();
    if (now > user.verificationCodeExpiry) {
      return false; // Code expired
    }

    if (user.phoneVerificationCode === code && user.phone === phone) {
      await db.update(users).set({
        isPhoneVerified: true,
        phoneVerificationCode: null,
        verificationCodeExpiry: null,
        updatedAt: new Date()
      }).where(eq(users.id, userId));
      
      await this.updateAccountVerificationStatus(userId);
      return true;
    }

    return false;
  }

  async updateAccountVerificationStatus(userId: string): Promise<void> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    
    if (user && (user.isEmailVerified || user.isPhoneVerified)) {
      await db.update(users).set({
        isAccountVerified: true,
        updatedAt: new Date()
      }).where(eq(users.id, userId));
    }
  }

  // Fraud detection operations
  async createFraudDetection(fraudData: InsertFraudDetection): Promise<FraudDetection> {
    const [fraud] = await db.insert(fraudDetection).values(fraudData).returning();
    return fraud;
  }

  async getFraudDetectionByUser(userId: string): Promise<FraudDetection[]> {
    return db.select().from(fraudDetection).where(eq(fraudDetection.userId, userId)).orderBy(desc(fraudDetection.createdAt));
  }

  async getAllFraudDetection(): Promise<FraudDetection[]> {
    return db.select().from(fraudDetection).orderBy(desc(fraudDetection.createdAt));
  }

  async updateFraudDetectionStatus(id: string, status: string): Promise<void> {
    await db.update(fraudDetection).set({ status }).where(eq(fraudDetection.id, id));
  }

  // Rate limiting operations
  async createRateLimit(rateLimitData: InsertRateLimit): Promise<RateLimit> {
    const [rateLimit] = await db.insert(rateLimits).values(rateLimitData).returning();
    return rateLimit;
  }

  async getRateLimitByIdentifier(identifier: string, action: string): Promise<RateLimit | undefined> {
    const [rateLimit] = await db.select().from(rateLimits)
      .where(and(eq(rateLimits.identifier, identifier), eq(rateLimits.action, action)))
      .limit(1);
    return rateLimit;
  }

  async updateRateLimit(id: string, count: number): Promise<void> {
    await db.update(rateLimits).set({ count, lastActivity: new Date() }).where(eq(rateLimits.id, id));
  }
}

export const storage = new DatabaseStorage();
