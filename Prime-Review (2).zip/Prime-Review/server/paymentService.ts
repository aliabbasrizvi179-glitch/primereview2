import crypto from 'crypto';

export interface UPIPaymentRequest {
  amount: number;
  upiId: string;
  description: string;
  userId: string;
}

export interface RazorpayPaymentRequest {
  amount: number; // in paise (INR * 100)
  currency: string;
  receipt: string;
  notes?: any;
}

export interface PaymentResponse {
  success: boolean;
  paymentId?: string;
  orderId?: string;
  error?: string;
}

export class PaymentService {
  private razorpayKeyId: string;
  private razorpayKeySecret: string;

  constructor() {
    this.razorpayKeyId = process.env.RAZORPAY_KEY_ID || '';
    this.razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET || '';
  }

  // Razorpay Order Creation
  async createRazorpayOrder(request: RazorpayPaymentRequest): Promise<any> {
    try {
      // This would typically use Razorpay SDK
      // For now, we'll simulate the order creation
      const orderId = `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      return {
        id: orderId,
        entity: 'order',
        amount: request.amount,
        amount_paid: 0,
        amount_due: request.amount,
        currency: request.currency,
        receipt: request.receipt,
        status: 'created',
        attempts: 0,
        notes: request.notes || {},
        created_at: Math.floor(Date.now() / 1000)
      };
    } catch (error) {
      console.error('Razorpay order creation failed:', error);
      throw new Error('Payment order creation failed');
    }
  }

  // Verify Razorpay Payment
  verifyRazorpayPayment(orderId: string, paymentId: string, signature: string): boolean {
    try {
      const body = orderId + '|' + paymentId;
      const expectedSignature = crypto
        .createHmac('sha256', this.razorpayKeySecret)
        .update(body.toString())
        .digest('hex');

      return expectedSignature === signature;
    } catch (error) {
      console.error('Razorpay signature verification failed:', error);
      return false;
    }
  }

  // UPI Payment Processing (Simplified)
  async processUPIPayment(request: UPIPaymentRequest): Promise<PaymentResponse> {
    try {
      // In a real implementation, this would integrate with UPI payment gateway
      // For now, we'll simulate the UPI payment process
      
      // Basic UPI ID validation
      if (!this.validateUPIId(request.upiId)) {
        return {
          success: false,
          error: 'Invalid UPI ID format'
        };
      }

      // Simulate payment processing
      const transactionId = `UPI${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
      
      // In real implementation, you would:
      // 1. Create payment request to UPI gateway
      // 2. Wait for user confirmation
      // 3. Verify payment status
      
      return {
        success: true,
        paymentId: transactionId,
        orderId: `upi_order_${Date.now()}`
      };
    } catch (error) {
      console.error('UPI payment processing failed:', error);
      return {
        success: false,
        error: 'UPI payment processing failed'
      };
    }
  }

  // Validate UPI ID format
  private validateUPIId(upiId: string): boolean {
    // Basic UPI ID validation regex
    const upiRegex = /^[a-zA-Z0-9.-]+@[a-zA-Z0-9.-]+$/;
    return upiRegex.test(upiId);
  }

  // Process withdrawal to UPI
  async processUPIWithdrawal(amount: number, upiId: string, userId: string): Promise<PaymentResponse> {
    try {
      if (!this.validateUPIId(upiId)) {
        return {
          success: false,
          error: 'Invalid UPI ID'
        };
      }

      // Simulate withdrawal processing
      const transactionId = `WD${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
      
      // In real implementation:
      // 1. Initiate transfer to user's UPI ID
      // 2. Wait for confirmation
      // 3. Update payment status
      
      return {
        success: true,
        paymentId: transactionId
      };
    } catch (error) {
      console.error('UPI withdrawal failed:', error);
      return {
        success: false,
        error: 'Withdrawal processing failed'
      };
    }
  }

  // Verify webhook signature (for both Razorpay and UPI webhooks)
  verifyWebhookSignature(payload: string, signature: string, secret: string): boolean {
    try {
      const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(payload)
        .digest('hex');

      return crypto.timingSafeEqual(
        Buffer.from(signature, 'hex'),
        Buffer.from(expectedSignature, 'hex')
      );
    } catch (error) {
      console.error('Webhook signature verification failed:', error);
      return false;
    }
  }

  // Generate payment receipt
  generateReceipt(userId: string, type: string): string {
    const timestamp = Date.now();
    return `${type}_${userId}_${timestamp}`;
  }

  // Calculate platform fee
  calculatePlatformFee(amount: number, feePercentage: number = 2.5): number {
    return Math.round(amount * (feePercentage / 100));
  }

  // Format amount for Razorpay (convert to paise)
  formatAmountForRazorpay(amount: number): number {
    return Math.round(amount * 100); // Convert to paise
  }

  // Format amount from Razorpay (convert from paise)
  formatAmountFromRazorpay(amount: number): number {
    return amount / 100; // Convert from paise to rupees
  }
}