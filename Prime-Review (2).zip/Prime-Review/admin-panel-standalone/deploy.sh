#!/bin/bash

echo "🚀 Deploying Secure Admin Panel..."

# Make sure we're in the correct directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

# Create deployment package
echo "📦 Creating deployment package..."

# Create a temporary directory for deployment files
DEPLOY_DIR="secure-admin-panel-deploy"
ZIP_NAME="secure-admin-panel-$(date +%Y%m%d-%H%M%S).zip"

# Remove existing deployment directory if it exists
rm -rf "$DEPLOY_DIR"

# Create deployment directory structure
mkdir -p "$DEPLOY_DIR"

# Copy all necessary files
cp -r server "$DEPLOY_DIR/"
cp -r src "$DEPLOY_DIR/"
cp -r public "$DEPLOY_DIR/"
cp -r database "$DEPLOY_DIR/" 2>/dev/null || mkdir -p "$DEPLOY_DIR/database"
cp package.json "$DEPLOY_DIR/"
cp .env "$DEPLOY_DIR/" 2>/dev/null || echo "# Copy .env file here if needed" > "$DEPLOY_DIR/.env.example"
cp README.md "$DEPLOY_DIR/"
cp *.config.* "$DEPLOY_DIR/" 2>/dev/null || true
cp tsconfig*.json "$DEPLOY_DIR/" 2>/dev/null || true

# Create a startup script for easy deployment
cat > "$DEPLOY_DIR/start.sh" << 'EOF'
#!/bin/bash
echo "🚀 Starting Secure Admin Panel..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16 or higher."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm."
    exit 1
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install dependencies."
        exit 1
    fi
fi

# Create database directory if it doesn't exist
mkdir -p database

# Start the server
echo "🔧 Starting server..."
node server/index.js
EOF

# Make startup script executable
chmod +x "$DEPLOY_DIR/start.sh"

# Create Windows batch file
cat > "$DEPLOY_DIR/start.bat" << 'EOF'
@echo off
echo Starting Secure Admin Panel...

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js is not installed. Please install Node.js 16 or higher.
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo Installing dependencies...
    npm install
    if %errorlevel% neq 0 (
        echo Failed to install dependencies.
        pause
        exit /b 1
    )
)

if not exist "database" mkdir database

echo Starting server...
node server/index.js
pause
EOF

# Create deployment instructions
cat > "$DEPLOY_DIR/DEPLOYMENT.md" << 'EOF'
# Deployment Instructions

## Quick Start

### Linux/macOS:
```bash
chmod +x start.sh
./start.sh
```

### Windows:
Double-click `start.bat` or run in Command Prompt:
```cmd
start.bat
```

### Manual:
```bash
npm install
node server/index.js
```

## Default Access

- URL: http://localhost:5000
- Email: admin@admin.com
- Password: admin123

**⚠️ Change the password immediately after first login!**

## Environment Setup

1. Copy `.env.example` to `.env`
2. Update configuration as needed
3. Ensure port 5000 is available

## Requirements

- Node.js 16 or higher
- npm (comes with Node.js)
- At least 100MB free disk space

## Troubleshooting

- If port 5000 is in use, change PORT in .env file
- For permission issues on Linux/macOS: `chmod +x start.sh`
- For Windows execution policy issues, run PowerShell as Administrator and run: `Set-ExecutionPolicy RemoteSigned`
EOF

# Create ZIP file
echo "🗜️ Creating ZIP archive: $ZIP_NAME"
zip -r "$ZIP_NAME" "$DEPLOY_DIR/" -q

# Clean up temporary directory
rm -rf "$DEPLOY_DIR"

echo "✅ Deployment package created successfully!"
echo "📁 File: $ZIP_NAME"
echo ""
echo "📋 To deploy:"
echo "1. Upload $ZIP_NAME to your server"
echo "2. Unzip the file: unzip $ZIP_NAME"
echo "3. Navigate to the folder: cd secure-admin-panel-deploy"
echo "4. Run: ./start.sh (Linux/macOS) or start.bat (Windows)"
echo ""
echo "🌐 Default access: http://localhost:5000"
echo "🔑 Default login: admin@admin.com / admin123"