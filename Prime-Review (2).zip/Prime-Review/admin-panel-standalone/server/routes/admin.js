const express = require('express');
const { body, validationResult } = require('express-validator');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { authenticateAdmin } = require('../middleware/auth');
const { getDatabase } = require('../database/init');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../../public/uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'), false);
    }
  }
});

// Apply authentication middleware to all admin routes
router.use(authenticateAdmin);

// Dashboard Statistics
router.get('/dashboard/stats', (req, res) => {
  const db = getDatabase();
  
  const queries = [
    'SELECT COUNT(*) as totalUsers FROM users',
    'SELECT COUNT(*) as totalBrands FROM brands',
    'SELECT COUNT(*) as totalCampaigns FROM campaigns WHERE status = "active"',
    'SELECT COUNT(*) as pendingReviews FROM reviews WHERE status = "pending"',
    'SELECT COALESCE(SUM(spent_amount), 0) as totalRevenue FROM campaigns'
  ];

  Promise.all(queries.map(query => 
    new Promise((resolve, reject) => {
      db.get(query, (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    })
  )).then(results => {
    const stats = {
      totalUsers: results[0].totalUsers,
      totalBrands: results[1].totalBrands,
      activeCampaigns: results[2].totalCampaigns,
      pendingReviews: results[3].pendingReviews,
      totalRevenue: results[4].totalRevenue
    };
    res.json({ success: true, data: stats });
  }).catch(err => {
    console.error('Stats query error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch statistics' });
  });
});

// User Management
router.get('/users', (req, res) => {
  const db = getDatabase();
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const offset = (page - 1) * limit;
  const search = req.query.search || '';
  const status = req.query.status || '';

  let query = 'SELECT * FROM users';
  let countQuery = 'SELECT COUNT(*) as total FROM users';
  let params = [];
  let conditions = [];

  if (search) {
    conditions.push('(name LIKE ? OR email LIKE ?)');
    params.push(`%${search}%`, `%${search}%`);
  }

  if (status) {
    conditions.push('status = ?');
    params.push(status);
  }

  if (conditions.length > 0) {
    const whereClause = ' WHERE ' + conditions.join(' AND ');
    query += whereClause;
    countQuery += whereClause;
  }

  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(limit, offset);

  db.get(countQuery, params.slice(0, -2), (err, countResult) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Database error' });
    }

    db.all(query, params, (err, users) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Database error' });
      }

      res.json({
        success: true,
        data: {
          users,
          pagination: {
            total: countResult.total,
            page,
            limit,
            pages: Math.ceil(countResult.total / limit)
          }
        }
      });
    });
  });
});

// Create/Update User
router.post('/users', [
  body('email').isEmail().normalizeEmail(),
  body('name').trim().isLength({ min: 2 }),
  body('role').isIn(['user', 'brand'])
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  const { id, email, name, role, status = 'active' } = req.body;
  const db = getDatabase();

  if (id) {
    // Update existing user
    db.run(
      'UPDATE users SET email = ?, name = ?, role = ?, status = ? WHERE id = ?',
      [email, name, role, status, id],
      function(err) {
        if (err) {
          if (err.code === 'SQLITE_CONSTRAINT') {
            return res.status(400).json({ success: false, message: 'Email already exists' });
          }
          return res.status(500).json({ success: false, message: 'Database error' });
        }
        res.json({ success: true, message: 'User updated successfully' });
      }
    );
  } else {
    // Create new user
    db.run(
      'INSERT INTO users (email, name, role, status) VALUES (?, ?, ?, ?)',
      [email, name, role, status],
      function(err) {
        if (err) {
          if (err.code === 'SQLITE_CONSTRAINT') {
            return res.status(400).json({ success: false, message: 'Email already exists' });
          }
          return res.status(500).json({ success: false, message: 'Database error' });
        }
        res.json({ success: true, message: 'User created successfully', userId: this.lastID });
      }
    );
  }
});

// Block/Unblock User
router.patch('/users/:id/status', (req, res) => {
  const { status } = req.body;
  const userId = req.params.id;
  
  if (!['active', 'blocked'].includes(status)) {
    return res.status(400).json({ success: false, message: 'Invalid status' });
  }

  const db = getDatabase();
  db.run(
    'UPDATE users SET status = ? WHERE id = ?',
    [status, userId],
    function(err) {
      if (err) {
        return res.status(500).json({ success: false, message: 'Database error' });
      }
      if (this.changes === 0) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
      res.json({ success: true, message: `User ${status} successfully` });
    }
  );
});

// Review Management
router.get('/reviews', (req, res) => {
  const db = getDatabase();
  const status = req.query.status || 'pending';
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const offset = (page - 1) * limit;

  const query = `
    SELECT r.*, u.name as user_name, u.email as user_email, c.title as campaign_title
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    LEFT JOIN campaigns c ON r.campaign_id = c.id
    WHERE r.status = ?
    ORDER BY r.submitted_at DESC
    LIMIT ? OFFSET ?
  `;

  db.all(query, [status, limit, offset], (err, reviews) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Database error' });
    }

    // Get total count
    db.get('SELECT COUNT(*) as total FROM reviews WHERE status = ?', [status], (err, countResult) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Database error' });
      }

      res.json({
        success: true,
        data: {
          reviews,
          pagination: {
            total: countResult.total,
            page,
            limit,
            pages: Math.ceil(countResult.total / limit)
          }
        }
      });
    });
  });
});

// Approve/Decline Review
router.patch('/reviews/:id/status', [
  body('status').isIn(['approved', 'declined']),
  body('adminNotes').optional().trim()
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  const { status, adminNotes } = req.body;
  const reviewId = req.params.id;
  const db = getDatabase();

  // Start transaction
  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    // Update review status
    db.run(
      'UPDATE reviews SET status = ?, admin_notes = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?',
      [status, adminNotes || null, reviewId],
      function(err) {
        if (err) {
          db.run('ROLLBACK');
          return res.status(500).json({ success: false, message: 'Database error' });
        }

        if (this.changes === 0) {
          db.run('ROLLBACK');
          return res.status(404).json({ success: false, message: 'Review not found' });
        }

        if (status === 'approved') {
          // Get review details to credit user
          db.get('SELECT * FROM reviews WHERE id = ?', [reviewId], (err, review) => {
            if (err) {
              db.run('ROLLBACK');
              return res.status(500).json({ success: false, message: 'Database error' });
            }

            // Credit user wallet
            db.run(
              'UPDATE users SET wallet_balance = wallet_balance + ?, total_earnings = total_earnings + ?, reviews_count = reviews_count + 1 WHERE id = ?',
              [review.reward_amount, review.reward_amount, review.user_id],
              (err) => {
                if (err) {
                  db.run('ROLLBACK');
                  return res.status(500).json({ success: false, message: 'Failed to credit user' });
                }

                // Create payment record
                db.run(
                  'INSERT INTO payments (user_id, amount, type, status) VALUES (?, ?, ?, ?)',
                  [review.user_id, review.reward_amount, 'reward', 'completed'],
                  (err) => {
                    if (err) {
                      db.run('ROLLBACK');
                      return res.status(500).json({ success: false, message: 'Failed to create payment record' });
                    }

                    db.run('COMMIT');
                    res.json({ success: true, message: 'Review approved and user credited' });
                  }
                );
              }
            );
          });
        } else {
          db.run('COMMIT');
          res.json({ success: true, message: 'Review declined' });
        }
      }
    );
  });
});

// Payment Management
router.get('/payments', (req, res) => {
  const db = getDatabase();
  const type = req.query.type || '';
  const status = req.query.status || '';
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const offset = (page - 1) * limit;

  let query = `
    SELECT p.*, u.name as user_name, u.email as user_email
    FROM payments p
    JOIN users u ON p.user_id = u.id
  `;
  
  let params = [];
  let conditions = [];

  if (type) {
    conditions.push('p.type = ?');
    params.push(type);
  }

  if (status) {
    conditions.push('p.status = ?');
    params.push(status);
  }

  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }

  query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
  params.push(limit, offset);

  db.all(query, params, (err, payments) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Database error' });
    }

    // Get total count
    let countQuery = 'SELECT COUNT(*) as total FROM payments p';
    if (conditions.length > 0) {
      countQuery += ' WHERE ' + conditions.join(' AND ');
    }

    db.get(countQuery, params.slice(0, -2), (err, countResult) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Database error' });
      }

      res.json({
        success: true,
        data: {
          payments,
          pagination: {
            total: countResult.total,
            page,
            limit,
            pages: Math.ceil(countResult.total / limit)
          }
        }
      });
    });
  });
});

// Content Management - Banners
router.get('/banners', (req, res) => {
  const db = getDatabase();
  db.all('SELECT * FROM banners ORDER BY display_order ASC, created_at DESC', (err, banners) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Database error' });
    }
    res.json({ success: true, data: banners });
  });
});

router.post('/banners', upload.single('image'), [
  body('title').trim().isLength({ min: 1 }),
  body('linkUrl').optional().isURL()
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  const { title, linkUrl, position = 'home', displayOrder = 0 } = req.body;
  const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

  if (!imageUrl) {
    return res.status(400).json({ success: false, message: 'Image is required' });
  }

  const db = getDatabase();
  db.run(
    'INSERT INTO banners (title, image_url, link_url, position, display_order) VALUES (?, ?, ?, ?, ?)',
    [title, imageUrl, linkUrl || null, position, displayOrder],
    function(err) {
      if (err) {
        return res.status(500).json({ success: false, message: 'Database error' });
      }
      res.json({ success: true, message: 'Banner created successfully', bannerId: this.lastID });
    }
  );
});

// Notifications
router.get('/notifications', (req, res) => {
  const db = getDatabase();
  db.all('SELECT * FROM notifications ORDER BY created_at DESC', (err, notifications) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Database error' });
    }
    res.json({ success: true, data: notifications });
  });
});

router.post('/notifications', [
  body('title').trim().isLength({ min: 1 }),
  body('message').trim().isLength({ min: 1 }),
  body('type').optional().isIn(['info', 'warning', 'success', 'error']),
  body('targetUsers').optional().isIn(['all', 'users', 'brands'])
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  const { title, message, type = 'info', targetUsers = 'all' } = req.body;
  const db = getDatabase();

  db.run(
    'INSERT INTO notifications (title, message, type, target_users) VALUES (?, ?, ?, ?)',
    [title, message, type, targetUsers],
    function(err) {
      if (err) {
        return res.status(500).json({ success: false, message: 'Database error' });
      }
      res.json({ success: true, message: 'Notification created successfully' });
    }
  );
});

// Settings Management
router.get('/settings', (req, res) => {
  const db = getDatabase();
  db.all('SELECT * FROM settings ORDER BY key ASC', (err, settings) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Database error' });
    }

    // Convert to key-value object
    const settingsObj = {};
    settings.forEach(setting => {
      let value = setting.value;
      if (setting.type === 'number') {
        value = parseFloat(value);
      } else if (setting.type === 'boolean') {
        value = value === 'true';
      } else if (setting.type === 'json') {
        try {
          value = JSON.parse(value);
        } catch (e) {
          value = null;
        }
      }
      settingsObj[setting.key] = value;
    });

    res.json({ success: true, data: settingsObj });
  });
});

router.post('/settings', (req, res) => {
  const settings = req.body;
  const db = getDatabase();

  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    const updates = Object.entries(settings);
    let completed = 0;
    let hasError = false;

    updates.forEach(([key, value]) => {
      let stringValue = value;
      if (typeof value === 'object') {
        stringValue = JSON.stringify(value);
      } else if (typeof value === 'boolean') {
        stringValue = value.toString();
      } else {
        stringValue = String(value);
      }

      db.run(
        'UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = ?',
        [stringValue, key],
        (err) => {
          if (err && !hasError) {
            hasError = true;
            db.run('ROLLBACK');
            return res.status(500).json({ success: false, message: 'Failed to update settings' });
          }

          completed++;
          if (completed === updates.length && !hasError) {
            db.run('COMMIT');
            res.json({ success: true, message: 'Settings updated successfully' });
          }
        }
      );
    });
  });
});

// API Keys Management
router.get('/api-keys', (req, res) => {
  const db = getDatabase();
  db.all('SELECT id, service_name, key_name, is_active, created_at FROM api_keys ORDER BY service_name', (err, keys) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Database error' });
    }
    res.json({ success: true, data: keys });
  });
});

router.post('/api-keys', [
  body('serviceName').trim().isLength({ min: 1 }),
  body('keyName').trim().isLength({ min: 1 }),
  body('keyValue').trim().isLength({ min: 1 })
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  const { serviceName, keyName, keyValue } = req.body;
  const db = getDatabase();

  db.run(
    'INSERT OR REPLACE INTO api_keys (service_name, key_name, key_value, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)',
    [serviceName, keyName, keyValue],
    function(err) {
      if (err) {
        return res.status(500).json({ success: false, message: 'Database error' });
      }
      res.json({ success: true, message: 'API key saved successfully' });
    }
  );
});

// Database Backup
router.get('/database/backup', (req, res) => {
  const db = getDatabase();
  const backup = [];

  const tables = ['admins', 'users', 'brands', 'campaigns', 'reviews', 'payments', 'notifications', 'banners', 'settings', 'api_keys'];

  let completed = 0;
  tables.forEach(table => {
    db.all(`SELECT * FROM ${table}`, (err, rows) => {
      if (err) {
        return res.status(500).json({ success: false, message: `Error backing up ${table}` });
      }

      backup.push({ table, data: rows });
      completed++;

      if (completed === tables.length) {
        res.json({
          success: true,
          data: {
            backup,
            timestamp: new Date().toISOString(),
            version: '1.0'
          }
        });
      }
    });
  });
});

module.exports = router;