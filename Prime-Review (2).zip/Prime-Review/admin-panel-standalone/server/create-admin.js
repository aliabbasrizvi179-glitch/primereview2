const bcrypt = require('bcryptjs');
const { initDatabase, getDatabase } = require('./database/init');

async function createAdmin() {
  try {
    console.log('🔧 Initializing database...');
    await initDatabase();
    
    const db = getDatabase();
    
    // Get admin details from command line arguments or use defaults
    const email = process.argv[2] || 'admin@admin.com';
    const password = process.argv[3] || 'admin123';
    const name = process.argv[4] || 'System Administrator';
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);
    
    // Create or update admin
    db.run(
      'INSERT OR REPLACE INTO admins (email, password, name, role) VALUES (?, ?, ?, ?)',
      [email, hashedPassword, name, 'admin'],
      function(err) {
        if (err) {
          console.error('❌ Error creating admin:', err);
        } else {
          console.log('✅ Admin user created successfully!');
          console.log(`📧 Email: ${email}`);
          console.log(`🔑 Password: ${password}`);
          console.log('');
          console.log('⚠️  Please change the password after first login!');
        }
        process.exit(0);
      }
    );
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

createAdmin();