import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { admin, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  // API Queries
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/dashboard/stats"],
    enabled: !!admin,
  });

  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
    enabled: !!admin && activeTab === 'users',
  });

  const { data: reviews = [], isLoading: reviewsLoading } = useQuery({
    queryKey: ["/api/admin/reviews?status=pending"],
    enabled: !!admin && activeTab === 'reviews',
  });

  const { data: payments = [], isLoading: paymentsLoading } = useQuery({
    queryKey: ["/api/admin/payments"],
    enabled: !!admin && activeTab === 'payments',
  });

  const { data: banners = [], isLoading: bannersLoading } = useQuery({
    queryKey: ["/api/admin/banners"],
    enabled: !!admin && activeTab === 'content',
  });

  const { data: notifications = [], isLoading: notificationsLoading } = useQuery({
    queryKey: ["/api/admin/notifications"],
    enabled: !!admin && activeTab === 'content',
  });

  const { data: settings = {}, isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/admin/settings"],
    enabled: !!admin && activeTab === 'settings',
  });

  // Mutations
  const reviewMutation = useMutation({
    mutationFn: async ({ reviewId, status, adminNotes }: { reviewId: string; status: string; adminNotes?: string }) => {
      return apiRequest("PATCH", `/api/admin/reviews/${reviewId}/status`, { status, adminNotes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reviews?status=pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/dashboard/stats"] });
      toast({ title: "Review updated successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const userStatusMutation = useMutation({
    mutationFn: async ({ userId, status }: { userId: string; status: string }) => {
      return apiRequest("PATCH", `/api/admin/users/${userId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "User status updated successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const createNotificationMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/admin/notifications", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/notifications"] });
      toast({ title: "Notification created successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const settingsMutation = useMutation({
    mutationFn: async (settings: any) => {
      return apiRequest("POST", "/api/admin/settings", settings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
      toast({ title: "Settings updated successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-lg">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-primary">Secure Admin</h1>
          <p className="text-sm text-muted-foreground">Management Panel</p>
        </div>
        
        <div className="px-6 mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <i className="fas fa-user text-white text-sm"></i>
            </div>
            <div>
              <p className="font-medium text-gray-900">{admin?.name}</p>
              <p className="text-xs text-gray-500">{admin?.email}</p>
            </div>
          </div>
        </div>
        
        <nav className="mt-6">
          <ul className="space-y-2 px-4">
            <li><button onClick={() => setActiveTab('dashboard')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'dashboard' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-dashboard">
              <i className="fas fa-tachometer-alt"></i><span>Dashboard</span>
            </button></li>
            <li><button onClick={() => setActiveTab('users')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'users' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-users">
              <i className="fas fa-users"></i><span>User Management</span>
            </button></li>
            <li><button onClick={() => setActiveTab('brands')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'brands' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-brands">
              <i className="fas fa-building"></i><span>Brand Management</span>
            </button></li>
            <li><button onClick={() => setActiveTab('campaigns')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'campaigns' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-campaigns">
              <i className="fas fa-bullhorn"></i><span>Campaign Oversight</span>
            </button></li>
            <li><button onClick={() => setActiveTab('reviews')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'reviews' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-reviews">
              <i className="fas fa-clipboard-check"></i><span>Review Approval</span>
            </button></li>
            <li><button onClick={() => setActiveTab('payments')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'payments' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-payments">
              <i className="fas fa-credit-card"></i><span>Payment Management</span>
            </button></li>
            <li><button onClick={() => setActiveTab('analytics')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'analytics' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-analytics">
              <i className="fas fa-chart-bar"></i><span>Analytics</span>
            </button></li>
            <li><button onClick={() => setActiveTab('database')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'database' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-database">
              <i className="fas fa-database"></i><span>Database Control</span>
            </button></li>
            <li><button onClick={() => setActiveTab('settings')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
              activeTab === 'settings' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`} data-testid="nav-settings">
              <i className="fas fa-cog"></i><span>System Settings</span>
            </button></li>
          </ul>
        </nav>
        
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t">
          <Button
            variant="outline"
            size="sm"
            onClick={logout}
            className="w-full"
            data-testid="button-logout"
          >
            <i className="fas fa-sign-out-alt mr-2"></i>
            Logout
          </Button>
        </div>
      </aside>
      
      {/* Main Admin Content */}
      <main className="flex-1 p-6">
        {activeTab === 'dashboard' && (
          <>
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-foreground mb-2">Admin Dashboard</h2>
              <p className="text-muted-foreground">Manage your review platform efficiently</p>
            </div>
            
            {/* Admin Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Total Users</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-users">{stats?.totalUsers || 0}</p>
                    </div>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <i className="fas fa-users text-primary text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Active Brands</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-brands">{stats?.totalBrands || 0}</p>
                    </div>
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                      <i className="fas fa-building text-accent text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Active Campaigns</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-campaigns">{stats?.activeCampaigns || 0}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-bullhorn text-blue-600 text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Pending Reviews</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-reviews">{stats?.pendingReviews || 0}</p>
                    </div>
                    <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-clock text-yellow-600 text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Total Revenue</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-revenue">₹{stats?.totalRevenue?.toLocaleString() || '0'}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-rupee-sign text-green-600 text-lg"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}

        {/* Database Control */}
        {activeTab === 'database' && (
          <div className="mb-8">
            <h3 className="text-2xl font-semibold text-foreground mb-6">Database Control Panel</h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
              {/* Users Database Control */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold text-foreground flex items-center">
                      <i className="fas fa-users mr-2 text-primary"></i>
                      Users Table
                    </h4>
                    <Badge variant="secondary">{users?.users?.length || 0} records</Badge>
                  </div>
                  <div className="space-y-3">
                    <Button className="w-full" data-testid="button-create-user-db">
                      <i className="fas fa-plus mr-2"></i>Create New User
                    </Button>
                    <Button variant="outline" className="w-full" data-testid="button-view-users-db">
                      <i className="fas fa-eye mr-2"></i>View All Users
                    </Button>
                    <Button variant="outline" className="w-full" data-testid="button-edit-users-db">
                      <i className="fas fa-edit mr-2"></i>Bulk Edit Users
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Campaigns Database Control */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold text-foreground flex items-center">
                      <i className="fas fa-bullhorn mr-2 text-primary"></i>
                      Campaigns Table
                    </h4>
                    <Badge variant="secondary">{0} records</Badge>
                  </div>
                  <div className="space-y-3">
                    <Button className="w-full" data-testid="button-create-campaign-db">
                      <i className="fas fa-plus mr-2"></i>Create New Campaign
                    </Button>
                    <Button variant="outline" className="w-full" data-testid="button-view-campaigns-db">
                      <i className="fas fa-eye mr-2"></i>View All Campaigns
                    </Button>
                    <Button variant="outline" className="w-full" data-testid="button-edit-campaigns-db">
                      <i className="fas fa-edit mr-2"></i>Bulk Edit Campaigns
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Reviews Database Control */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold text-foreground flex items-center">
                      <i className="fas fa-star mr-2 text-primary"></i>
                      Reviews Table
                    </h4>
                    <Badge variant="secondary">{reviews?.reviews?.length || 0} records</Badge>
                  </div>
                  <div className="space-y-3">
                    <Button className="w-full" data-testid="button-create-review-db">
                      <i className="fas fa-plus mr-2"></i>Create New Review
                    </Button>
                    <Button variant="outline" className="w-full" data-testid="button-view-reviews-db">
                      <i className="fas fa-eye mr-2"></i>View All Reviews
                    </Button>
                    <Button variant="outline" className="w-full" data-testid="button-edit-reviews-db">
                      <i className="fas fa-edit mr-2"></i>Bulk Edit Reviews
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Advanced Database Operations */}
            <Card>
              <CardContent className="p-6">
                <h4 className="font-semibold text-foreground mb-4 flex items-center">
                  <i className="fas fa-database mr-2 text-primary"></i>
                  Advanced Database Operations
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Button variant="outline" data-testid="button-backup-db">
                    <i className="fas fa-download mr-2"></i>Backup Database
                  </Button>
                  <Button variant="outline" data-testid="button-restore-db">
                    <i className="fas fa-upload mr-2"></i>Restore Database
                  </Button>
                  <Button variant="outline" data-testid="button-export-all-db">
                    <i className="fas fa-file-export mr-2"></i>Export All Data
                  </Button>
                  <Button variant="outline" data-testid="button-sql-query-db">
                    <i className="fas fa-terminal mr-2"></i>Run SQL Query
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Other tabs placeholder */}
        {activeTab !== 'dashboard' && activeTab !== 'database' && (
          <div className="text-center py-12">
            <i className="fas fa-tools text-4xl text-muted-foreground mb-4"></i>
            <h3 className="text-xl font-semibold text-foreground mb-2">Feature Under Development</h3>
            <p className="text-muted-foreground">This feature is being developed. Connect to the main platform for full functionality.</p>
          </div>
        )}
      </main>
    </div>
  );
}