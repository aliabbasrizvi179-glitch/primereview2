import { QueryClient } from "@tanstack/react-query";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
      retry: 1,
      queryFn: async ({ queryKey }) => {
        const token = localStorage.getItem('admin_token');
        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
        };
        
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }

        const response = await fetch(queryKey[0] as string, { headers });
        if (!response.ok) {
          if (response.status === 401) {
            localStorage.removeItem('admin_token');
            window.location.href = '/';
            throw new Error('Unauthorized - redirecting to login');
          }
          throw new Error(`${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        return data.data || data; // Handle API response format
      },
    },
  },
});

// API request helper for mutations
export async function apiRequest(method: string, url: string, data?: any) {
  const token = localStorage.getItem('admin_token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    method,
    headers,
    body: data ? JSON.stringify(data) : undefined,
  });

  if (!response.ok) {
    if (response.status === 401) {
      localStorage.removeItem('admin_token');
      window.location.href = '/';
      throw new Error('Unauthorized - redirecting to login');
    }
    const error = await response.json();
    throw new Error(error.message || `HTTP ${response.status}`);
  }

  return response.json();
}